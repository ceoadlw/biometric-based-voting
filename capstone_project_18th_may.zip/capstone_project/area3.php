<?php

$servername = "localhost";
$username = "newuser";
$password = "password";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	$firstname =  $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $age = $_POST['age'];
    $date = $_POST['date'];
    $newdate = date("Y-m-d",strtotime($date));
    $gender =  $_POST['gender'];
    $permanentadd = $_POST['permanent'];
    $nid = $_POST['nid'];

    $result = $conn->query("select * from area where nid = '$nid'");
    if($result->num_rows == 0)
    {

    $area = "area3";
    $stmt = $conn->prepare("INSERT INTO area (fname,lname,nid,areaname) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $firstname, $lastname, $nid, $area);
    $stmt->execute();

    $stmt = $conn->prepare("INSERT INTO area3 (fname,lname,age,dob,gender,permanentaddress,nid) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssissss", $firstname, $lastname, $age, $newdate, $gender, $permanentadd, $nid);
    $stmt->execute();
    ?>
    <!DOCTYPE html>
    <html>
        <head>
        <title>
        
        </title>
        <link rel="stylesheet" href="newcss/area_success.css">
        </head>
        <body>
            <div id="display-success">
            <img src="newcss/correct.png" alt="Success" /> YOU HAVE REGISTERED SUCCESFFULLY
            </div>

            <a href="face_capture.html">REGISTER YOUR FACE HERE </a>
    </body>
    </html>

    <?php

    }
    else
    {
        ?>
        <!DOCTYPE html>
        <html>
            <head>
            <title>
        
            </title>
            <link rel="stylesheet" href="newcss/already_registered.css">
            </head>
            <body>
                <div id="display-error">
                    YOU ARE ALREADY REGISTERED
                </div>
                <a href="menu.html"> CLICK HERE FOR HOME PAGE </a>
            </body>
            </html>

        <?php    
        
    }
}

$stmt->close();
$conn->close();

?>