from PIL import Image
import tkinter as tk
from tkinter import filedialog
import hashlib 
import binascii
import textwrap
import cv2
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
from importlib import reload  
from bisect import bisect_left as bsearch
import decryp
import mysql.connector
from mysql.connector import Error
import _pickle as cPickle

''' 
GLOBAL Constants
'''
# Lorenz paramters and initial conditions
a, b, c = 10, 2.667, 28
x0, y0, z0 = 0, 0, 0

#DNA-Encoding RULE #1 A = 00, T=01, G=10, C=11
dna={}
dna["00"]="A"
dna["01"]="T"
dna["10"]="G"
dna["11"]="C"
dna["A"]=[0,0]
dna["T"]=[0,1]
dna["G"]=[1,0]
dna["C"]=[1,1]
#DNA xor
dna["AA"]=dna["TT"]=dna["GG"]=dna["CC"]="A"
dna["AG"]=dna["GA"]=dna["TC"]=dna["CT"]="G"
dna["AC"]=dna["CA"]=dna["GT"]=dna["TG"]="C"
dna["AT"]=dna["TA"]=dna["CG"]=dna["GC"]="T"
# Maximum time point and total number of time points
tmax, N = 100, 10000


#program exec9
if (__name__ == "__main__"):

    hash_value = 0
    filename = 'upload_encrypted_images/enc.jpg'
    with open(filename,"rb") as f:
        bytes = f.read() # read entire file as bytes
        readable_hash = hashlib.sha256(bytes).hexdigest();
        hash_value = readable_hash
        print(hash_value)

    
    connection = mysql.connector.connect(user='newuser', password='password', host='127.0.0.1', database='capstone')
    cursor = connection.cursor()

    sql = "select enc_data from area where enc_hash = %s"
    cursor.execute(sql, (hash_value,))
    rows = cursor.fetchall()

    for each in rows:
    ## The result is also in a tuple
        for pickledStoredList in each:
        ## Unpickle the stored string
            unpickledList = cPickle.loads(pickledStoredList)
            # print unpickledList
            print("decrypting...")
            decryp.decrypt(unpickledList[0],unpickledList[1],unpickledList[2],unpickledList[3],unpickledList[4],unpickledList[5],unpickledList[6],unpickledList[7],unpickledList[8])
 
    
    
    
    
    
    
    
