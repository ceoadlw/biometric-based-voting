<!DOCTYPE html>
<html>
<head>
<link href='https://fonts.googleapis.com/css?family=Open Sans:400,700' rel='stylesheet' type='text/css'>
<link href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="../newcss/vote_cast.css">
</head>
<body class="container">
<h1>Elections</h1>
<div class="table-responsive">
<table class="table table-bordered">
<thead>
<tr>
<th>Party</th>
<th>Votes</th>
</tr>
</thead>
<tbody>
<tr>
<td>BJP</td>
<td id="candidate-1"></td>
</tr>
<tr>
<td>NCP</td>
<td id="candidate-2"></td>
</tr>
<tr>
<td>AAP</td>
<td id="candidate-3"></td>
</tr>
</tbody>
</table>
</div>

<form method="post" action="vote_insertion.php" id="candidate_form">


<div class="table-responsive">
<table class="table table-bordered">
<thead>
<tr>
<th>Account Address</th>
<th>Transaction Hash</th>
</tr>
</thead>
<tbody>
<tr>
<td id="account"></td>
<td id="transaction"></td>
</tr>
</tbody>
</table>
</div>

<div id='hide-div'>

<div class="textbox">
<input type="text" id="candidate" />
<a href="#" onclick="voteForCandidate()" class="btn btn-primary">VOTE</a>
</div>
	
</div>


<span id="result" name="result" hidden></span>
<script>
	document.getElementById('result').innerHTML = localStorage.getItem("hash_value");
</script>

<div class="hidden_anchor">
<span id="blockno" name="blockno" hidden></span>
<a id='homebutton' href='../menu.html' name="homebutton" style="display:none">GO TO HOME PAGE</a>
</div>

</form>
</body>
<script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.37/dist/web3.min.js"></script>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="./index.js"></script>
</html>