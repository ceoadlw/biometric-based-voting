web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:7545"))
var account;
web3.eth.getAccounts().then((f) => {
  account = f[0]; //update value here to update your account
})

abi = JSON.parse('[{"constant":true,"inputs":[{"name":"candidate","type":"bytes32"}],"name":"totalVotesFor","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"candidate","type":"bytes32"}],"name":"validCandidate","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"bytes32"}],"name":"votesReceived","outputs":[{"name":"","type":"uint8"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"candidateList","outputs":[{"name":"","type":"bytes32"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"candidate","type":"bytes32"}],"name":"voteForCandidate","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[{"name":"candidateNames","type":"bytes32[]"}],"payable":false,"stateMutability":"nonpayable","type":"constructor"}]')

contract = new web3.eth.Contract(abi);
contract.options.address = "0x7DDC985891eEd2040ECCe7F9926C2Af5fD7D2866";
// update this contract address with your contract address

candidates = {"BJP": "candidate-1", "NCP": "candidate-2", "AAP": "candidate-3"};

function voteForCandidate() {
  candidateName = $("#candidate").val();
  if(candidates.hasOwnProperty(candidateName))
  {
  console.log(candidateName);
  contract.methods.voteForCandidate(web3.utils.asciiToHex(candidateName)).send({from: account}).then((f) => {
    let div_id = candidates[candidateName];
    // alert(JSON.stringify(f));
    $("#account").html(account); 
    //acc.push(account);
    $("#transaction").html(f["transactionHash"]); 
    //t.push(f["transactionHash"]);
    $("#blockno").html(f["blockNumber"]);
    contract.methods.totalVotesFor(web3.utils.asciiToHex(candidateName)).call().then((f) => {
      $("#" + div_id).html(f);    
      
      var account = document.getElementById("account").innerHTML;
      var transactionid = document.getElementById("transaction").innerHTML;
      var hash_value = document.getElementById("result").innerHTML;
      var blockno = document.getElementById("blockno").innerHTML;

      $.post(
        'vote_insertion.php',
          {
            candidateName: candidateName,
            account: account,
            transactionid: transactionid,
            hash_value: hash_value,
            blockno: blockno
        },
        function(data){
           alert(data);
       }
    );


    })
  })
  document.getElementById('hide-div').style.display = 'none'; 
  var homebutton = $("#homebutton");
  homebutton.show();
}
  else
  {
    window.alert("PLEASE ENTER THE CORRECT CANDIDATE NAME");
  }
}

$(document).ready(function() {
  candidateNames = Object.keys(candidates);

  for(var i=0; i<candidateNames.length; i++) {
    let name = candidateNames[i];
  
    contract.methods.totalVotesFor(web3.utils.asciiToHex(name)).call().then((f) => {
      $("#" + candidates[name]).html(f);
    })

  }

});


