<?php
  
$servername = "localhost";
$username = "newuser";
$password = "password";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}

// $candidateName = $_POST['candidateName'];
// $account = $_POST['account'];
// $transactionid = $_POST['transactionid'];

// SQL query to select data from database
// $stmt = $conn->prepare("INSERT INTO blockchain (candidateName,account,transactionid) VALUES (?, ?, ?)");
// $stmt->bind_param("sss", $candidateName, $account, $transactionid);

// $stmt = $conn->prepare("INSERT INTO blockchain (account,transactionid) VALUES (?, ?)");
// $stmt->bind_param("ss", $account, $transactionid);
// $stmt->execute();

$candidate = $_POST['candidateName'];
$account = $_POST['account'];
$transactionid = $_POST['transactionid'];
$hash_value = $_POST['hash_value'];
$blockno = $_POST['blockno'];

$stmt = $conn->prepare("INSERT INTO blockchaintable (candidateName,account,transactionid,blockno) VALUES (?,?,?,?)");
$stmt->bind_param("ssss", $candidate, $account, $transactionid, $blockno);
$stmt->execute();

$stmt2 = $conn->query("update area set voted=1 where enc_hash = '$hash_value'");

// echo $transactionid;
echo "successfully voted";
// echo $hash_value;

// $stmt->close();
$stmt2->close();
$conn->close();

?>