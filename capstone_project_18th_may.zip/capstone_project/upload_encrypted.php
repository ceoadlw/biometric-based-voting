<?php

if(isset($_POST['submit']))
{
    $file = $_FILES['file'];

    $fileName = $_FILES['file']['name'];
    $fileTmpName = $_FILES['file']['tmp_name'];
    $fileSize = $_FILES['file']['size'];
    $fileError = $_FILES['file']['error'];
    $fileType = $_FILES['file']['type'];

    $fileExt = explode('.',$fileName);
    $fileActualExt = strtolower(end($fileExt));

    $allowed = array('jpg','jpeg','png');

    if(in_array($fileActualExt, $allowed))
    {
        if($fileError === 0)
        {
            if($fileSize<1000000)
            {
                $fileNameNew = 'enc'.".".'jpg';
                $fileDestination = 'upload_encrypted_images/'.$fileNameNew;
                move_uploaded_file($fileTmpName,$fileDestination);
                ?>

                <!DOCTYPE html>
                <html>
                    <head>
                        <link rel="stylesheet" href="newcss/area_success.css">
        	        </head>
        	        <body>
            	        <div id="display-success">
                        <img src="newcss/correct.png" alt="Success" />
				        	IMAGE SUCCESSFULLY UPLOADED
           		        </div>
                	    <a href="check_encrypted_image.php"> CLICK HERE TO PROCEED </a>
    		        </body>
                </html>

                <?php
            }
            else
            {
                echo "YOUR FILE IS TOO BIG!";
            }
        }
        else
        {
            echo "THERE WAS ERROR UPLOADING THIS FILE!";
        }
    }
    else
    {
        echo "YOU CANNOT UPLOAD FILES OF THIS TYPE!";
    }

}

?>