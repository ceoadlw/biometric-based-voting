<?php

		$output = shell_exec("python3 /var/www/html/capstone_project/encr.py");

?>

    <!DOCTYPE html>
    <html>
        <head>
        <title>
        
        </title>
        <link rel="stylesheet" href="newcss/area_success.css">
        </head>
        <body>
            <div id="display-success">
            <img src="newcss/correct.png" alt="Success" /> YOU HAVE UPLOADED SUCCESSFULLY
            </div>

            <a href="hash.php"> CLICK HERE TO GENERATE HASH </a>
    </body>
    </html>
