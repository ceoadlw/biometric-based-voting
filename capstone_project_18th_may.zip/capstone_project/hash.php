<?php

	$servername = "localhost";
	$username = "newuser";
	$password = "password";
	$dbname = "capstone";

	$conn = new mysqli($servername, $username, $password, $dbname);

	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	
	$hash_generated = hash_file('sha256', 'encrypted_images/enc.jpg'); 

	$result = $conn->query("select nid from area order by updated_at desc limit 1");
	if($result->num_rows == 0)
	{
		echo "YOU ARE NOT REGISTERED";
	}
	else 
	{
		$row = $result->fetch_row();
		$stmt = $conn->prepare("update area set enc_hash = ? where nid = ?");
    	$stmt->bind_param("ss", $hash_generated, $row[0]);
    	$stmt->execute();
    	?>

    	<!DOCTYPE html>
    	<html>
        	<head>
        	<title>
        
        	</title>
        	<link rel="stylesheet" href="newcss/area_success.css">
        	</head>
        	<body>
            	<div id="display-success">
            		<img src="newcss/correct.png" alt="Success" /> IMAGE CAPTURED SUCCESSFULLY
           		</div>

            	<a href="menu.html"> CLICK HERE FOR HOME PAGE </a>
    		</body>
    	</html>

    	<?php
	}

	
$stmt->close();
$conn->close();

?>