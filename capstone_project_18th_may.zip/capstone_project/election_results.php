<!DOCTYPE html UTF-8>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="newcss/election_results.css">
        <script src='https://cdn.plot.ly/plotly-latest.min.js'></script>
    </head>
    <body>

<?php

$servername = "localhost";
$username = "newuser";
$password = "password";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}

$sql = "select candidateName,count(*) as count from blockchaintable group by candidateName";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

?>

<br>
<div class="table-wrapper">
    <table class="fl-table">
            <thead>
            <tr>
                <th>CANDIDATE NAME</th>
                <th>VOTE COUNT</th>
            </tr>
            </thead>
            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
            <?php   // LOOP TILL END OF DATA
                $i = 0; 
                while($rows=$result->fetch_assoc())
                {
                    $array[] = $rows;
            ?>
            <tr>
                <!--FETCHING DATA FROM EACH ROW OF EVERY COLUMN-->
                <td><?php echo $array[$i]['candidateName'];?></td>
                <td><?php echo $array[$i]['count'];?></td>
            </tr>

            <?php
             
                $i = $i + 1;
                }

                $bjpcount = $array[0]['count'];
                $ncpcount = $array[1]['count'];
                $aapcount = $array[2]['count'];

                echo "<script>var bjpcnt = \"$bjpcount\";</script>";
                echo "<script>var ncpcnt = \"$ncpcount\";</script>";
                echo "<script>var aapcnt = \"$aapcount\";</script>";

            }
            else
            {
                ?>
                <!DOCTYPE html>
                <html>
                    <head>
                    <title>

                    </title>
                    <link rel="stylesheet" href="newcss/already_registered.css">
                    </head>
                    <body>
                        <div id="display-error">
                            NO RESULTS
                        </div>
                        <a href="menu.html">CLICK HERE FOR HOME PAGE </a>
                    </body>
                </html>

            <?php    
            }
            ?>

        </table>

        </div>

        <div class="graph">
        <div id='myElect'> </div>

        <script>
            // localStorage.setItem("bjp",bjpcnt);
            // localStorage.setItem("ncp",ncpcnt);
            // localStorage.setItem("aap",aapcnt);

            var xValue = ['BJP', 'NCP', 'AAP'];

            var yValue = [bjpcnt, ncpcnt, aapcnt];

            var trace1 = {
            x: xValue,
            y: yValue,
            type: 'bar',
            text: yValue.map(String),
            textposition: 'auto',
            hoverinfo: 'none',
            marker: {
                color: 'rgb(158,202,225)',
                opacity: 0.6,
                line: {
                color: 'rgb(8,48,107)',
                width: 1.5
                }
            }
            };

            var data = [trace1];

            var layout = {
            title: 'ELECTION RESULTS',
            barmode: 'stack',
            height: 500,
            width: 500, 
            xaxis:{
                title: 'CANDIDATES'
            },
            yaxis:{
                title: 'VOTES RECEIVED'
            },
            margin: {
                l: 100,
                r: 100,
                b: 100,
                t: 100,
                pad: 4
                }
            };

            Plotly.newPlot('myElect', data, layout , {responsive: true});
        </script>
        </div>

        <a href="menu.html">CLICK HERE FOR HOME PAGE </a>
    </body>
</html>
