from PIL import Image
import tkinter as tk
from tkinter import filedialog
import hashlib 
import binascii
import textwrap
import cv2
import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
from importlib import reload  
from bisect import bisect_left as bsearch
import key_gen
import _pickle as cPickle
import mysql.connector
from mysql.connector import Error

''' 
GLOBAL Constants
'''
# Lorenz paramters and initial conditions
a, b, c = 10, 2.667, 28
x0, y0, z0 = 0, 0, 0

#DNA-Encoding RULE #1 A = 00, T=01, G=10, C=11
dna={}
dna["00"]="A"
dna["01"]="T"
dna["10"]="G"
dna["11"]="C"
dna["A"]=[0,0]
dna["T"]=[0,1]
dna["G"]=[1,0]
dna["C"]=[1,1]
#DNA xor
dna["AA"]=dna["TT"]=dna["GG"]=dna["CC"]="A"
dna["AG"]=dna["GA"]=dna["TC"]=dna["CT"]="G"
dna["AC"]=dna["CA"]=dna["GT"]=dna["TG"]="C"
dna["AT"]=dna["TA"]=dna["CG"]=dna["GC"]="T"
# Maximum time point and total number of time points
tmax, N = 100, 10000


#program exec9
if (__name__ == "__main__"):
    file_path = key_gen.image_selector()
    print(file_path)
    key, m, n = key_gen.securekey(file_path)

    key_gen.update_lorentz(key)
    blue,green,red = key_gen.decompose_matrix(file_path)
    blue_e,green_e,red_e = key_gen.dna_encode(blue,green,red)
    Mk_e = key_gen.key_matrix_encode(key,blue)
    blue_final, green_final, red_final = key_gen.xor_operation(blue_e,green_e,red_e,Mk_e)

    x,y,z = key_gen.gen_chaos_seq(m,n)
    fx,fy,fz=key_gen.sequence_indexing(x,y,z)
    blue_scrambled,green_scrambled,red_scrambled = key_gen.scramble(fx,fy,fz,blue_final,red_final,green_final)

    b,g,r = key_gen.dna_decode(blue_scrambled,green_scrambled,red_scrambled)
    img = key_gen.recover_image(b,g,r,file_path)

    listToPickle = img,fx,fy,fz,file_path,Mk_e,blue,green,red
    pickledList = cPickle.dumps(listToPickle)

    connection = mysql.connector.connect(user='newuser', password='password', host='127.0.0.1', database='capstone')
    cursor = connection.cursor()

    sql = "select nid from area order by updated_at desc limit 1"
    cursor.execute(sql)
    rows = cursor.fetchall()

    sql2 = "update area set enc_data = %s where nid = %s"
    for row in rows:
        val = (pickledList, row[0])
    cursor.execute(sql2, val)
    connection.commit()

