<?php
$servername = "localhost";
$username = "newuser";
$password = "password";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($_SERVER["REQUEST_METHOD"] == "POST")
{
	$sql = "select name from adminlog where name = ? and password = ?";
	if($stmt = $conn->prepare($sql))
	{
        $stmt->bind_param("ss", $_POST['adminid'], $_POST['password']);
        if($stmt->execute())
        {
            $stmt->store_result();    
            if($stmt->num_rows == 1){
                echo("successful login");
				header("location: menu.html");
            } 
            else
            {
                ?>
            <!DOCTYPE html>
                <html>
                    <head>
                    <title>
        
                    </title>
                    <link rel="stylesheet" href="newcss/already_registered.css">
                    </head>
                    <body>
                    <div id="display-error">
                        YOUR LOGIN CREDENTIALS ARE INAVLID
                    </div>
                    <a href="admin_login.html">CLICK HERE TO TRY AGAIN</a>
                    </body>
                </html>
            
            <?php
            }
        }
    }
}
$stmt->close();
$conn->close();
?>