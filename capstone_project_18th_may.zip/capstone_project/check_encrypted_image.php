<?php
	$servername = "localhost";
	$username = "newuser";
	$password = "password";
	$dbname = "capstone";

	$conn = new mysqli($servername, $username, $password, $dbname);

	if ($conn->connect_error) 
	{
		die("Connection failed: " . $conn->connect_error);
	}
	
	$hash_generated = hash_file('sha256', 'upload_encrypted_images/enc.jpg'); 

	echo "<script>var js_variable = \"$hash_generated\";</script>"; // Passing to JavaScript variable
	?>
	<script>
		localStorage.setItem("hash_value",js_variable); 
	</script>


	<?php
	$voted = $conn->query("select * from area where enc_hash = '$hash_generated'");
	$rows = $voted->fetch_assoc();

	if($voted->num_rows == 0)
	{
		?>

		<!DOCTYPE html>
    	<html>
        	<head>
        	<title>
        
        	</title>
        	<link rel="stylesheet" href="newcss/already_registered.css">
        	</head>
        	<body>
            	<div id="display-error">
					YOU ARE NOT REGISTERED
           		</div>

            	<a href="menu.html"> CLICK HERE FOR HOME PAGE </a>
    		</body>
    	</html>

		<?php
	}
	else if($rows['voted']==1)
	{
		?>
		<!DOCTYPE html>
    	<html>
        	<head>
        	<title>
        
        	</title>
        	<link rel="stylesheet" href="newcss/already_registered.css">
        	</head>
        	<body>
            	<div id="display-error">
					YOU HAVE ALREADY VOTED
           		</div>

            	<a href="menu.html"> CLICK HERE FOR HOME PAGE </a>
    		</body>
    	</html>
		<?php
	}
	else 
	{
		$output = shell_exec("python3 /var/www/html/capstone_project/second_main.py");

		?>

		<html>
			<head>
			<link rel="stylesheet" href="newcss/authenticate.css">
			</head>
			<body>
				<div>
				<a href='http://localhost:5050/login'>AUTHENTICATE</a>
				</div>
			</body>
		</html>
	<?php

	}

$conn->close();
?>