<?php
  
$servername = "localhost";
$username = "newuser";
$password = "password";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) 
{
	die("Connection failed: " . $conn->connect_error);
}
  
// SQL query to select data from database
$transactionid = $_POST['transactionid'];
$sql = "SELECT * FROM blockchaintable where transactionid = '$transactionid'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {

?>

<!DOCTYPE html>
<html lang="en">
  
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" type="text/css" href="newcss/election_results.css">
</head>
  
<body>
    <div class="table-wrapper">
        <table class="fl-table">
            <thead>
            <tr>
                <th>CANDIDATE NAME</th>
                <th>ACCOUNT</th>
                <th>TRANSACTION</th>
                <th>BLOCK NUMBER</th>
                <th>VOTED AT</th>
            </tr>
            </thead>

            <!-- PHP CODE TO FETCH DATA FROM ROWS-->
            <?php   // LOOP TILL END OF DATA 
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!--FETCHING DATA FROM EACH ROW OF EVERY COLUMN-->
                <td><?php echo $rows['candidateName'];?></td>
                <td><?php echo $rows['account'];?></td>
                <td><?php echo $rows['transactionid'];?></td>
                <td><?php echo $rows['blockno'];?></td>
                <td><?php echo $rows['updated_at'];?></td>
            </tr>
            <?php
                }
            }
            else
            {
                ?>
                <!DOCTYPE html>
                <html>
                    <head>
                    <title>

                    </title>
                    <link rel="stylesheet" href="newcss/already_registered.css">
                    </head>
                    <body>
                        <div id="display-error">
                            NO RESULTS
                        </div>
                        <a href="menu.html">CLICK HERE FOR HOME PAGE </a>
                    </body>
                </html>

            <?php    
            }
            ?>
            <a href="menu.html">CLICK HERE FOR HOME PAGE </a>
        </table>
    </div>
</body>
</html>