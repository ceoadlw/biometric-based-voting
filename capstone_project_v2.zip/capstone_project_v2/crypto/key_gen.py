"""
Key generation and chaotic sequence helpers.
Implements DNA encoding/decoding and Lorenz chaotic scrambling
as described in: N. M.K and R. K.R, "Secured Key Generation for
Biometric Encryption using Hyper-chaotic Map and DNA Sequences."
"""
import hashlib
import textwrap
import numpy as np
from scipy.integrate import odeint
from bisect import bisect_left as bsearch

from .dna_base import DNA, LORENZ_A, LORENZ_B, LORENZ_C, T_MAX


# ---------------------------------------------------------------------------
# Key derivation
# ---------------------------------------------------------------------------

def compute_image_key(image_path: str) -> tuple:
    """SHA-256 hash of all pixel values. Returns (hex_key, width, height)."""
    from PIL import Image
    img = Image.open(image_path)
    w, h = img.size
    pix = img.load()
    data = bytearray()
    for y in range(h):
        for x in range(w):
            for k in range(3):
                data.append(pix[x, y][k])
    key = hashlib.sha256(data).hexdigest()
    return key, w, h


def derive_lorenz_params(key: str, x0: float = 0.0, y0: float = 0.0, z0: float = 0.0):
    """Perturb Lorenz initial conditions using the key's binary representation."""
    key_bin = bin(int(key, 16))[2:].zfill(256)
    parts = textwrap.wrap(key_bin, 8)   # 32 × 8-bit parts
    t1 = t2 = t3 = 0
    for i in range(11):
        t1 ^= int(parts[i], 2)
    for i in range(11, 22):
        t2 ^= int(parts[i], 2)
    for i in range(22, 32):
        t3 ^= int(parts[i], 2)
    return x0 + t1 / 256.0, y0 + t2 / 256.0, z0 + t3 / 256.0


# ---------------------------------------------------------------------------
# Lorenz chaos sequence
# ---------------------------------------------------------------------------

def _lorenz(X, t, a, b, c):
    x, y, z = X
    return -a * (x - y), c * x - y - x * z, -b * z + x * y


def generate_chaos_sequences(m: int, n: int, x0: float, y0: float, z0: float):
    """Generate three Lorenz chaos sequences of length m*n*4."""
    N = m * n * 4
    t = np.linspace(0, T_MAX, N)
    f = odeint(_lorenz, (x0, y0, z0), t, args=(LORENZ_A, LORENZ_B, LORENZ_C))
    return f[:, 0], f[:, 1], f[:, 2]


def sequence_to_permutation(seq):
    """Convert a real-valued sequence to a true rank-order permutation using argsort.
    np.argsort always produces unique indices (0..N-1), making it a valid permutation."""
    return np.argsort(seq).astype(np.uint32)


# ---------------------------------------------------------------------------
# Image channel helpers
# ---------------------------------------------------------------------------

def split_channels(image):
    """Return (red, green, blue) slices from a BGR OpenCV image."""
    return image[:, :, 2], image[:, :, 1], image[:, :, 0]


def load_channels(image_path: str):
    """Load image and return (B, G, R) channel matrices."""
    import cv2
    img = cv2.imread(image_path)
    return (
        np.asmatrix(img[:, :, 0]),
        np.asmatrix(img[:, :, 1]),
        np.asmatrix(img[:, :, 2]),
    )


# ---------------------------------------------------------------------------
# DNA operations on channel matrices
# ---------------------------------------------------------------------------

def dna_encode_channels(b, g, r):
    """DNA-encode each channel matrix."""
    result = []
    for ch in (b, g, r):
        bits = np.unpackbits(np.array(ch, dtype=np.uint8), axis=1)
        m, n = bits.shape
        enc = np.chararray((m, n // 2))
        for j in range(m):
            for i in range(0, n, 2):
                enc[j, i // 2] = DNA[f'{bits[j, i]}{bits[j, i+1]}']
        result.append(enc.astype(str))
    return tuple(result)


def build_key_matrix(key: str, ref_channel) -> np.ndarray:
    """Build a DNA-encoded key matrix matching the shape of a channel matrix."""
    bits = np.unpackbits(np.array(np.frombuffer(bytes.fromhex(key), dtype=np.uint8)))
    ch = np.array(ref_channel, dtype=np.uint8)
    ch_bits = np.unpackbits(ch, axis=1)
    m, n_bits = ch_bits.shape
    Mk = np.zeros((m, n_bits), dtype=np.uint8)
    x = 0
    for j in range(m):
        for i in range(n_bits):
            Mk[j, i] = bits[x % 256]
            x += 1
    enc = np.chararray((m, n_bits // 2))
    for j in range(m):
        for i in range(0, n_bits, 2):
            enc[j, i // 2] = DNA[f'{Mk[j, i]}{Mk[j, i+1]}']
    return enc.astype(str)


def dna_xor(b, g, r, mk):
    """XOR DNA-encoded channels with a key matrix."""
    m, n = b.shape
    result = []
    for ch in (b, g, r):
        res = np.chararray((m, n))
        for i in range(m):
            for j in range(n):
                res[i, j] = DNA[f'{ch[i, j]}{mk[i, j]}']
        result.append(res.astype(str))
    return tuple(result)


def scramble_forward(fx, fy, fz, b, r, g):
    """
    Scramble channels using Lorenz permutation indices (encryption direction).
    Argument order matches encrypt.py: (fx,fy,fz, blue, red, green)
    Returns (blue_s, green_s, red_s).
    Uses numpy advanced indexing — O(n) and type-safe.
    """
    p, q = np.asarray(b).shape
    size = p * q

    bx = np.asarray(b, dtype='U1').reshape(size)
    gx = np.asarray(g, dtype='U1').reshape(size)
    rx = np.asarray(r, dtype='U1').reshape(size)

    fz_safe = fz % size
    fy_safe = fy % size
    fx_safe = fx % size

    return (
        bx[fz_safe].reshape(p, q),
        gx[fy_safe].reshape(p, q),
        rx[fx_safe].reshape(p, q),
    )


def scramble_inverse(fx, fy, fz, b, g, r):
    """Reverse scramble (decryption direction). Computes inverse permutations
    and applies them — guaranteed perfect recovery when fx/fy/fz are true permutations."""
    p, q = np.asarray(b).shape
    size = p * q

    bx = np.asarray(b, dtype='U1').reshape(size)
    gx = np.asarray(g, dtype='U1').reshape(size)
    rx = np.asarray(r, dtype='U1').reshape(size)

    # Build inverse permutations: inv[perm[i]] = i
    fz_safe = fz % size
    fy_safe = fy % size
    fx_safe = fx % size

    inv_fz = np.empty(size, dtype=np.uint32)
    inv_fy = np.empty(size, dtype=np.uint32)
    inv_fx = np.empty(size, dtype=np.uint32)
    inv_fz[fz_safe] = np.arange(size, dtype=np.uint32)
    inv_fy[fy_safe] = np.arange(size, dtype=np.uint32)
    inv_fx[fx_safe] = np.arange(size, dtype=np.uint32)

    return (
        bx[inv_fz].reshape(p, q),
        gx[inv_fy].reshape(p, q),
        rx[inv_fx].reshape(p, q),
    )


def dna_decode_channels(b, g, r):
    """DNA-decode channel matrices back to uint8."""
    result = []
    for ch in (b, g, r):
        m, n = ch.shape
        dec = np.ndarray((m, n * 2), dtype=np.uint8)
        for j in range(m):
            for i in range(n):
                val = DNA[str(ch[j, i])]
                dec[j, 2 * i] = val[0]
                dec[j, 2 * i + 1] = val[1]
        result.append(np.packbits(dec, axis=-1))
    return tuple(result)
