"""
Biometric image encryption using DNA encoding + Lorenz chaotic scrambling.

Pipeline:
  1. Derive SHA-256 key from plain face image.
  2. Update Lorenz initial conditions from key.
  3. Decompose into B, G, R channels.
  4. DNA-encode channels.
  5. Build and XOR with key matrix.
  6. Generate Lorenz chaos sequences → permutation indices.
  7. Scramble channels with permutation indices.
  8. DNA-decode → write encrypted image.
  9. Pickle intermediate values + store hash in DB.
"""
import hashlib
import pickle
import cv2

from .key_gen import (
    compute_image_key,
    derive_lorenz_params,
    load_channels,
    dna_encode_channels,
    build_key_matrix,
    dna_xor,
    generate_chaos_sequences,
    sequence_to_permutation,
    scramble_forward,
    dna_decode_channels,
)


def encrypt_face(face_path: str, enc_output_path: str, nid: str, db_conn) -> str:
    """
    Encrypt the face image at *face_path*, write the encrypted image to
    *enc_output_path*, persist the blob + hash against *nid* in *db_conn*.

    Returns the SHA-256 hash of the encrypted image file.
    """
    # 1. Key derivation
    key, w, h = compute_image_key(face_path)

    # 2. Lorenz parameter update
    x0, y0, z0 = derive_lorenz_params(key)

    # 3. Channel decomposition
    b_ch, g_ch, r_ch = load_channels(face_path)

    # 4. DNA encode
    b_enc, g_enc, r_enc = dna_encode_channels(b_ch, g_ch, r_ch)

    # 5. Key matrix + XOR
    mk = build_key_matrix(key, b_ch)
    b_xor, g_xor, r_xor = dna_xor(b_enc, g_enc, r_enc, mk)

    # 6. Chaos sequences
    x_seq, y_seq, z_seq = generate_chaos_sequences(h, w, x0, y0, z0)
    fx = sequence_to_permutation(x_seq)
    fy = sequence_to_permutation(y_seq)
    fz = sequence_to_permutation(z_seq)

    # 7. Scramble (note: original passes red before green to scramble_forward)
    b_s, g_s, r_s = scramble_forward(fx, fy, fz, b_xor, r_xor, g_xor)

    # 8. DNA decode → pixel values
    b_out, g_out, r_out = dna_decode_channels(b_s, g_s, r_s)

    # Write encrypted image (BGR order)
    img = cv2.imread(face_path)
    img[:, :, 0] = b_out
    img[:, :, 1] = g_out
    img[:, :, 2] = r_out
    cv2.imwrite(enc_output_path, img)

    # 9. Hash of encrypted file
    with open(enc_output_path, 'rb') as f:
        enc_hash = hashlib.sha256(f.read()).hexdigest()

    # Pickle parameters needed for decryption
    payload = pickle.dumps((img, fx, fy, fz, face_path, mk, b_ch, g_ch, r_ch))

    # Persist in DB
    db_conn.execute(
        'UPDATE voters SET enc_data = ?, enc_hash = ? WHERE nid = ?',
        (payload, enc_hash, nid),
    )
    db_conn.commit()

    return enc_hash
