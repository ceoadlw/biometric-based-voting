# DNA Encoding Rule #1: A=00, T=01, G=10, C=11
DNA = {
    '00': 'A', '01': 'T', '10': 'G', '11': 'C',
    'A': [0, 0], 'T': [0, 1], 'G': [1, 0], 'C': [1, 1],
    # XOR rules
    'AA': 'A', 'TT': 'A', 'GG': 'A', 'CC': 'A',
    'AG': 'G', 'GA': 'G', 'TC': 'G', 'CT': 'G',
    'AC': 'C', 'CA': 'C', 'GT': 'C', 'TG': 'C',
    'AT': 'T', 'TA': 'T', 'CG': 'T', 'GC': 'T',
}

# Lorenz chaotic system parameters
LORENZ_A = 10
LORENZ_B = 2.667
LORENZ_C = 28

# Chaos sequence time range
T_MAX = 100
