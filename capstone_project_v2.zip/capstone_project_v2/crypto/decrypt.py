"""
Biometric image decryption — reverse of encrypt.py pipeline.

Given the uploaded encrypted image:
  1. Hash the uploaded file and look up the voter in the DB.
  2. Unpickle the stored parameters.
  3. Reverse the encryption steps to recover the original face image.
  4. Write the recovered image to *dec_output_path* for face recognition.

Returns one of: 'ok', 'not_registered', 'already_voted'
"""
import hashlib
import pickle
import numpy as np
import cv2

from .key_gen import (
    dna_encode_channels,
    dna_xor,
    dna_decode_channels,
    scramble_inverse,
    split_channels,
)


def decrypt_uploaded(uploaded_enc_path: str, dec_output_path: str, db_conn) -> tuple:
    """
    Decrypt the uploaded encrypted image and write the recovered face to
    *dec_output_path*.

    Returns ('ok', nid) on success, or ('not_registered', None) /
    ('already_voted', None) on failure.
    """
    # Hash uploaded file
    with open(uploaded_enc_path, 'rb') as f:
        enc_hash = hashlib.sha256(f.read()).hexdigest()

    row = db_conn.execute(
        'SELECT nid, enc_data, voted FROM voters WHERE enc_hash = ?',
        (enc_hash,),
    ).fetchone()

    if row is None:
        return 'not_registered', None
    if row['voted'] == 1:
        return 'already_voted', None

    nid = row['nid']
    img_enc, fx, fy, fz, _, mk, b_orig, g_orig, r_orig = pickle.loads(row['enc_data'])

    # Load encrypted image and split channels
    enc_img = cv2.imread(uploaded_enc_path)
    r_ch, g_ch, b_ch = split_channels(enc_img)   # OpenCV: ch2=R, ch1=G, ch0=B

    # Reverse pipeline:
    # Step 1: DNA-encode the encrypted channels
    b_enc, g_enc, r_enc = dna_encode_channels(
        np.asmatrix(b_ch), np.asmatrix(g_ch), np.asmatrix(r_ch)
    )

    # Step 2: Inverse scramble
    b_unscr, g_unscr, r_unscr = scramble_inverse(fx, fy, fz, b_enc, g_enc, r_enc)

    # Step 3: XOR with key matrix (XOR is self-inverse)
    b_xor, g_xor, r_xor = dna_xor(b_unscr, g_unscr, r_unscr, mk)

    # Step 4: DNA decode
    b_dec, g_dec, r_dec = dna_decode_channels(b_xor, g_xor, r_xor)

    # Reconstruct image (swap green/red to match original colour layout)
    p, q = np.array(r_orig).shape
    out = np.zeros((p, q, 3), dtype=np.uint8)
    out[:, :, 0] = r_dec     # ch0 (blue in OpenCV) ← r_dec
    out[:, :, 1] = b_dec     # ch1 (green)
    out[:, :, 2] = g_dec     # ch2 (red)
    cv2.imwrite(dec_output_path, out)

    return 'ok', nid
