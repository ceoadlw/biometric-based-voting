"""
SQLite database initialisation and connection helper.

Schema
------
admins   – administrator credentials
voters   – registered voters (replaces area / area1 / area2 / area3 tables)
"""
import base64
import hashlib
import hmac
import os
import os as _os
import sqlite3

DB_PATH = os.path.join(os.path.dirname(__file__), 'voters.db')


def hash_password(password: str) -> str:
    """Hash a password with PBKDF2-HMAC-SHA256 and a random 16-byte salt.
    Format: pbkdf2:sha256:<iterations>:<base64-salt>:<base64-hash>
    """
    salt = _os.urandom(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 260_000)
    return (
        f"pbkdf2:sha256:260000"
        f":{base64.b64encode(salt).decode()}"
        f":{base64.b64encode(dk).decode()}"
    )


def verify_password(stored: str, password: str) -> bool:
    """Verify a password against a stored PBKDF2 hash."""
    try:
        _, alg, iterations, salt_b64, hash_b64 = stored.split(':', 4)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
        candidate = hashlib.pbkdf2_hmac(alg, password.encode(), salt, int(iterations))
        return hmac.compare_digest(expected, candidate)
    except Exception:
        return False


# Pre-computed dummy hash used for constant-time login when username not found
_DUMMY_HASH = hash_password('__dummy__placeholder__')


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = get_db()
    cur = conn.cursor()

    cur.executescript('''
        CREATE TABLE IF NOT EXISTS admins (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            name          TEXT    UNIQUE NOT NULL,
            password_hash TEXT    NOT NULL
        );

        CREATE TABLE IF NOT EXISTS voters (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            fname      TEXT    NOT NULL,
            lname      TEXT    NOT NULL,
            nid        TEXT    UNIQUE NOT NULL,
            area       TEXT    NOT NULL,
            age        INTEGER,
            dob        TEXT,
            gender     TEXT,
            address    TEXT,
            enc_data   BLOB,
            enc_hash   TEXT,
            voted      INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
    ''')

    # Default admin: username "admin", password "admin"
    pw_hash = hash_password('admin')
    cur.execute(
        'INSERT OR IGNORE INTO admins (name, password_hash) VALUES (?, ?)',
        ('admin', pw_hash),
    )

    conn.commit()
    conn.close()
