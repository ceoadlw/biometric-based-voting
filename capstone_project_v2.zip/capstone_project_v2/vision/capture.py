"""
Face capture during voter registration.

Opens the webcam, detects the first face in the frame using the Haar
cascade classifier, crops it, resizes to 160×160 px, and saves it to
*output_path*.  Returns True on success, False if no face was found.
"""
import time
import cv2


_CASCADE = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)


def capture_face(output_path: str) -> bool:
    """
    Grab one frame from the default camera, detect a face, save the
    cropped face to *output_path*.  Returns True if a face was saved.
    """
    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    # Allow camera to warm up
    for _ in range(5):
        cam.read()

    ret, frame = cam.read()
    cam.release()

    if not ret:
        return False

    faces = _CASCADE.detectMultiScale(frame, scaleFactor=1.3, minNeighbors=5)
    if len(faces) == 0:
        return False

    x, y, w, h = faces[0]
    face_crop = frame[y: y + h, x: x + w]
    face_resized = cv2.resize(face_crop, (160, 160))
    cv2.imwrite(output_path, face_resized)
    return True


def stream_frames():
    """
    Generator that yields JPEG bytes continuously from the webcam.
    Keeps the camera open for the entire session (much faster than
    open/close per frame).  Yields None when the camera is unavailable.
    """
    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    # Allow camera to warm up before streaming
    for _ in range(5):
        cam.read()

    try:
        while True:
            ret, frame = cam.read()
            if not ret:
                time.sleep(0.05)
                continue

            faces = _CASCADE.detectMultiScale(frame, scaleFactor=1.3, minNeighbors=5)
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (67, 67, 67), 2)

            ok, jpeg = cv2.imencode('.jpg', frame)
            if ok:
                yield jpeg.tobytes()
            time.sleep(0.033)  # ~30 fps cap
    finally:
        cam.release()


def capture_frame_jpeg() -> bytes | None:
    """Grab one frame, return it as JPEG bytes (for a single-frame preview)."""
    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    for _ in range(5):
        cam.read()
    ret, frame = cam.read()
    cam.release()

    if not ret:
        return None

    faces = _CASCADE.detectMultiScale(frame, scaleFactor=1.3, minNeighbors=5)
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (67, 67, 67), 2)

    _, jpeg = cv2.imencode('.jpg', frame)
    return jpeg.tobytes()
