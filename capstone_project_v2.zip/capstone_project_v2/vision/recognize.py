"""
Live face recognition for voter authentication.

Loads the decrypted reference image and compares it against the live
webcam feed.  A global state variable tracks whether the current face
is 'Registered' (matched) or 'Unknown'.

When face_recognition (dlib) is available it performs full encoding
comparison; otherwise it falls back to Haar cascade presence detection
which is sufficient for a proof-of-concept deployment.
"""
import os
import time
import threading
import cv2
import numpy as np

try:
    import face_recognition
    # Pre-load dlib models at import time so the first stream request is instant
    import numpy as _np
    _blank = _np.zeros((64, 64, 3), dtype=_np.uint8)
    face_recognition.face_locations(_blank)
    del _blank, _np
except ImportError:
    face_recognition = None  # graceful degradation to Haar cascade fallback
except Exception:
    face_recognition = None


# ---------------------------------------------------------------------------
# Global state (one voter authenticates at a time)
# ---------------------------------------------------------------------------
_lock = threading.Lock()
_recognition_result: str = 'Unknown'   # 'Registered' or 'Unknown'

_CASCADE = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)


def get_result() -> str:
    with _lock:
        return _recognition_result


def reset_result() -> None:
    global _recognition_result
    with _lock:
        _recognition_result = 'Unknown'


# ---------------------------------------------------------------------------
# Recognition helpers
# ---------------------------------------------------------------------------

def _load_known_faces(db_dir: str) -> tuple:
    """Load all .png/.jpg images from *db_dir* as known face encodings."""
    names, encodings = [], []
    for fname in os.listdir(db_dir):
        if not fname.lower().endswith(('.png', '.jpg', '.jpeg')):
            continue
        path = os.path.join(db_dir, fname)
        img = face_recognition.load_image_file(path)
        encs = face_recognition.face_encodings(img)
        if encs:
            names.append(os.path.splitext(fname)[0])
            encodings.append(encs[0])
    return names, encodings


def _annotate_frame(frame, locations, names):
    """Draw bounding boxes and labels onto *frame* in-place."""
    for (top, right, bottom, left), name in zip(locations, names):
        top *= 4; right *= 4; bottom *= 4; left *= 4
        color = (0, 200, 0) if name != 'Unknown' else (0, 0, 200)
        cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
        cv2.rectangle(frame, (left, bottom - 30), (right, bottom), color, cv2.FILLED)
        cv2.putText(frame, name, (left + 6, bottom - 6),
                    cv2.FONT_HERSHEY_DUPLEX, 0.8, (255, 255, 255), 1)


# ---------------------------------------------------------------------------
# MJPEG generator — full face_recognition path
# ---------------------------------------------------------------------------

def _stream_with_face_recognition(cam, decrypted_dir: str):
    global _recognition_result
    known_names, known_encodings = _load_known_faces(decrypted_dir)

    while True:
        ret, frame = cam.read()
        if not ret:
            time.sleep(0.05)
            continue

        small = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small = small[:, :, ::-1]

        try:
            locations = face_recognition.face_locations(rgb_small)
            encodings = face_recognition.face_encodings(rgb_small, locations)
        except Exception:
            locations, encodings = [], []

        frame_names = []
        for enc in encodings:
            name = 'Unknown'
            if known_encodings:
                distances = face_recognition.face_distance(known_encodings, enc)
                best = int(np.argmin(distances))
                matches = face_recognition.compare_faces(known_encodings, enc)
                if matches[best]:
                    name = known_names[best]
            frame_names.append(name)

        with _lock:
            if frame_names and all(n != 'Unknown' for n in frame_names):
                _recognition_result = 'Registered'
            elif frame_names:
                _recognition_result = 'Unknown'

        _annotate_frame(frame, locations, frame_names)

        ok, jpeg = cv2.imencode('.jpg', frame)
        if ok:
            yield jpeg.tobytes()
        time.sleep(0.033)


# ---------------------------------------------------------------------------
# MJPEG generator — Haar cascade fallback (no dlib required)
# ---------------------------------------------------------------------------

def _stream_with_haar(cam):
    global _recognition_result
    MATCH_FRAMES = 10   # consecutive frames with a face → mark as Registered
    consecutive = 0

    while True:
        ret, frame = cam.read()
        if not ret:
            time.sleep(0.05)
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = _CASCADE.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)

        if len(faces) > 0:
            consecutive += 1
            for (x, y, w, h) in faces:
                color = (0, 200, 0) if consecutive >= MATCH_FRAMES else (255, 165, 0)
                cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                label = 'Registered' if consecutive >= MATCH_FRAMES else 'Scanning...'
                cv2.putText(frame, label, (x, y - 10),
                            cv2.FONT_HERSHEY_DUPLEX, 0.7, color, 1)
            with _lock:
                if consecutive >= MATCH_FRAMES:
                    _recognition_result = 'Registered'
        else:
            consecutive = 0
            with _lock:
                _recognition_result = 'Unknown'

        ok, jpeg = cv2.imencode('.jpg', frame)
        if ok:
            yield jpeg.tobytes()
        time.sleep(0.033)


# ---------------------------------------------------------------------------
# Public stream entry point
# ---------------------------------------------------------------------------

def recognition_stream(decrypted_dir: str):
    """
    Yield MJPEG frames while performing face authentication.
    Uses face_recognition (dlib) when available, Haar cascade otherwise.
    """
    cam = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    # Warm up
    for _ in range(5):
        cam.read()

    try:
        if face_recognition is not None:
            gen = _stream_with_face_recognition(cam, decrypted_dir)
        else:
            gen = _stream_with_haar(cam)

        for jpeg_bytes in gen:
            yield (
                b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n'
                + jpeg_bytes
                + b'\r\n\r\n'
            )
    finally:
        cam.release()
