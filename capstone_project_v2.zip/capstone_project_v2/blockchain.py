"""
Simple Python blockchain simulation for vote recording.

Each vote is a block containing:
  - block_index   : sequential position in the chain
  - tx_hash       : SHA-256 of block contents (acts as the transaction ID)
  - account       : voter's simulated wallet address (random hex string)
  - candidate     : party / candidate name
  - prev_hash     : hash of the preceding block
  - timestamp     : ISO-format timestamp

All blocks are stored in the SQLite `blockchain` table so they survive
restarts.  Chain integrity can be verified at any time.

Note: This is a proof-of-concept — a production system would use
Hyperledger Fabric or an Ethereum network (Solidity + Web3.js).
"""
import hashlib
import json
import os
import secrets
import sqlite3
import time

DB_PATH = os.path.join(os.path.dirname(__file__), 'voters.db')

_GENESIS_HASH = '0' * 64


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    conn.execute('''
        CREATE TABLE IF NOT EXISTS blockchain (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            block_index INTEGER NOT NULL,
            tx_hash     TEXT    UNIQUE NOT NULL,
            account     TEXT    NOT NULL,
            candidate   TEXT    NOT NULL,
            block_hash  TEXT    NOT NULL,
            prev_hash   TEXT    NOT NULL,
            timestamp   TEXT    NOT NULL
        )
    ''')
    conn.commit()
    return conn


def _compute_hash(data: dict) -> str:
    block_str = json.dumps(data, sort_keys=True)
    return hashlib.sha256(block_str.encode()).hexdigest()


def _last_block(conn: sqlite3.Connection) -> sqlite3.Row | None:
    return conn.execute(
        'SELECT * FROM blockchain ORDER BY block_index DESC LIMIT 1'
    ).fetchone()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_account() -> str:
    """Return a random 40-character hex string (simulated wallet address)."""
    return '0x' + secrets.token_hex(20)


def add_vote(account: str, candidate: str) -> dict:
    """
    Append a new vote block to the chain.
    Returns the block dict (including tx_hash and block_index).
    """
    conn = _get_conn()
    last = _last_block(conn)

    prev_hash = last['block_hash'] if last else _GENESIS_HASH
    block_index = (last['block_index'] + 1) if last else 1
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')

    # tx_hash is derived from block contents (not including block_hash itself)
    block_data = {
        'index': block_index,
        'account': account,
        'candidate': candidate,
        'prev_hash': prev_hash,
        'timestamp': timestamp,
    }
    tx_hash = _compute_hash(block_data)
    block_hash = hashlib.sha256((tx_hash + prev_hash).encode()).hexdigest()

    conn.execute(
        '''INSERT INTO blockchain
           (block_index, tx_hash, account, candidate, block_hash, prev_hash, timestamp)
           VALUES (?, ?, ?, ?, ?, ?, ?)''',
        (block_index, tx_hash, account, candidate, block_hash, prev_hash, timestamp),
    )
    conn.commit()
    conn.close()

    return {**block_data, 'tx_hash': tx_hash, 'block_hash': block_hash}


def get_all_blocks() -> list:
    """Return all blocks ordered by index ascending."""
    conn = _get_conn()
    rows = conn.execute(
        'SELECT * FROM blockchain ORDER BY block_index ASC'
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_block_by_tx(tx_hash: str) -> dict | None:
    """Lookup a single block by its transaction hash."""
    conn = _get_conn()
    row = conn.execute(
        'SELECT * FROM blockchain WHERE tx_hash = ?', (tx_hash,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_results() -> list:
    """Return vote counts per candidate, sorted by count descending."""
    conn = _get_conn()
    rows = conn.execute(
        '''SELECT candidate, COUNT(*) AS votes
           FROM blockchain
           GROUP BY candidate
           ORDER BY votes DESC'''
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def verify_chain() -> bool:
    """
    Walk the entire chain and verify hash integrity.
    Returns True if the chain is intact, False if tampered.
    """
    blocks = get_all_blocks()
    for i, block in enumerate(blocks):
        expected_prev = blocks[i - 1]['block_hash'] if i > 0 else _GENESIS_HASH
        if block['prev_hash'] != expected_prev:
            return False
        data = {
            'index': block['block_index'],
            'account': block['account'],
            'candidate': block['candidate'],
            'prev_hash': block['prev_hash'],
            'timestamp': block['timestamp'],
        }
        expected_tx = _compute_hash(data)
        if block['tx_hash'] != expected_tx:
            return False
    return True
