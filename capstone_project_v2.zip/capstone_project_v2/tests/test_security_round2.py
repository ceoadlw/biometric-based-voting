"""
Security Audit — Round 2
========================
Government security consultant perspective: these tests probe attack surfaces
that survived the first round of hardening.

Categories
----------
HDR  : HTTP security headers (clickjacking, CSP, MIME sniffing, cookies)
SESS : Session management (timeout, fixation, post-logout access)
AUTH : Brute-force / credential hardening
INFO : Information disclosure (error pages, server banners)
INP  : Input validation (long inputs, unicode, stored XSS in blockchain)
AC   : Access control (IDOR, privilege escalation)
BLKC : Blockchain persistence and tamper evidence
"""
import io
import sqlite3
import time

import pytest
from unittest.mock import patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _login(client, username='admin', password='admin'):
    return client.post('/login',
                       data={'adminid': username, 'password': password},
                       follow_redirects=False)


def _insert_voter(db_path, nid, enc_hash='h', voted=0):
    conn = sqlite3.connect(db_path)
    conn.execute(
        "INSERT OR IGNORE INTO voters "
        "(fname,lname,nid,area,age,enc_hash,enc_data,voted) "
        "VALUES ('A','B',?,?,25,?,?,?)",
        (nid, 'area1', enc_hash, b'x', voted))
    conn.commit()
    conn.close()


# ===========================================================================
# HDR — HTTP Security Headers
# ===========================================================================

class TestSecurityHeaders:

    def test_xframe_options_prevents_clickjacking(self, client):
        """HDR-01 [HIGH]: X-Frame-Options must be set to deny embedding in iframes.
        Without it an attacker can overlay the voting page in a hidden iframe
        and trick an admin into clicking UI elements (clickjacking)."""
        c, _, _ = client
        r = c.get('/login')
        header = r.headers.get('X-Frame-Options', '')
        assert header.upper() in ('DENY', 'SAMEORIGIN'), \
            f"FAIL [HIGH]: X-Frame-Options missing or weak: {header!r}"

    def test_content_type_nosniff(self, client):
        """HDR-02 [MEDIUM]: X-Content-Type-Options: nosniff must be present.
        Without it browsers may MIME-sniff an uploaded file as executable."""
        c, _, _ = client
        r = c.get('/login')
        assert r.headers.get('X-Content-Type-Options') == 'nosniff', \
            "FAIL [MEDIUM]: X-Content-Type-Options: nosniff not set"

    def test_session_cookie_httponly(self, client):
        """HDR-03 [HIGH]: Session cookie must have HttpOnly flag.
        Without it JavaScript can steal the session token via XSS."""
        import app as flask_app
        assert flask_app.app.config.get('SESSION_COOKIE_HTTPONLY', True), \
            "FAIL [HIGH]: SESSION_COOKIE_HTTPONLY disabled"
        # Also verify the Set-Cookie header on login response
        c, _, _ = client
        r = _login(c)
        set_cookie = r.headers.get('Set-Cookie', '')
        if set_cookie:
            assert 'httponly' in set_cookie.lower(), \
                f"FAIL [HIGH]: session cookie missing HttpOnly in Set-Cookie: {set_cookie}"

    def test_session_cookie_samesite(self, client):
        """HDR-04 [MEDIUM]: Session cookie should have SameSite attribute.
        Lax or Strict prevents CSRF via cookie tossing."""
        import app as flask_app
        samesite = flask_app.app.config.get('SESSION_COOKIE_SAMESITE', None)
        assert samesite in ('Lax', 'Strict'), \
            f"FAIL [MEDIUM]: SESSION_COOKIE_SAMESITE not set (got {samesite!r})"

    def test_no_server_header_leaking_version(self, client):
        """HDR-05 [LOW]: Server header should not reveal Flask/Werkzeug version."""
        c, _, _ = client
        r = c.get('/login')
        server = r.headers.get('Server', '')
        assert 'werkzeug' not in server.lower(), \
            f"FAIL [LOW]: Server header leaks framework version: {server!r}"


# ===========================================================================
# SESS — Session Management
# ===========================================================================

class TestSessionManagement:

    def test_session_invalidated_after_logout(self, client):
        """SESS-01 [HIGH]: After logout the old session cookie must be rejected.
        Reusing the pre-logout cookie must not grant access."""
        c, _, _ = client
        _login(c)
        # Capture cookie before logout
        r_menu = c.get('/menu')
        assert r_menu.status_code == 200

        c.get('/logout')

        # Try accessing protected route after logout
        r_after = c.get('/menu', follow_redirects=False)
        assert r_after.status_code == 302, \
            "FAIL [HIGH]: Protected page accessible after logout"
        assert 'login' in r_after.headers.get('Location', '').lower(), \
            "FAIL [HIGH]: Post-logout redirect does not go to login"

    def test_session_cookie_cleared_on_logout(self, client):
        """SESS-02 [MEDIUM]: Logout must clear the server-side session, not just
        redirect. Merely redirecting leaves the session token valid."""
        c, _, _ = client
        _login(c)
        with c.session_transaction() as sess:
            sess['admin'] = 'admin'  # confirm it's set

        c.get('/logout')

        with c.session_transaction() as sess:
            assert 'admin' not in sess, \
                "FAIL [MEDIUM]: admin key still in session after logout"

    def test_no_session_fixation(self, client):
        """SESS-03 [HIGH]: Login must not preserve pre-login session data.
        An attacker who injects a known session ID before login must not
        inherit the authenticated session."""
        c, _, _ = client
        # Plant a marker in the session before login
        c.get('/login')
        with c.session_transaction() as sess:
            sess['_probe'] = 'before_login'

        _login(c)

        # After login, the pre-login marker must be gone (session was regenerated)
        with c.session_transaction() as sess:
            assert '_probe' not in sess, \
                "FAIL [HIGH]: Pre-login session data survives login — " \
                "session fixation possible"


# ===========================================================================
# AUTH — Brute-force & Credential Hardening
# ===========================================================================

class TestBruteForce:

    def test_repeated_wrong_passwords_do_not_leak_timing(self, client):
        """AUTH-09 [MEDIUM]: Login timing must not differ significantly between
        'user not found' and 'wrong password' (timing oracle)."""
        c, _, _ = client
        N = 5

        t0 = time.monotonic()
        for _ in range(N):
            c.post('/login', data={'adminid': 'nonexistent', 'password': 'x'})
        t_nouser = (time.monotonic() - t0) / N

        t0 = time.monotonic()
        for _ in range(N):
            c.post('/login', data={'adminid': 'admin', 'password': 'wrongpass'})
        t_wrongpw = (time.monotonic() - t0) / N

        ratio = max(t_nouser, t_wrongpw) / (min(t_nouser, t_wrongpw) + 1e-9)
        assert ratio < 10, (
            f"FAIL [MEDIUM]: Login timing differs by {ratio:.1f}x between "
            f"'no user' ({t_nouser*1000:.1f}ms) and 'wrong password' "
            f"({t_wrongpw*1000:.1f}ms) — timing oracle possible"
        )

    def test_default_credentials_password_is_hashed_not_plaintext(self, client):
        """AUTH-10 [CRITICAL]: Admin password must NEVER be stored in plaintext.
        It must be a PBKDF2 hash. Note: the default password 'admin' is
        intentionally weak for this PoC demo — in production it MUST be changed
        to a strong credential before deployment."""
        import database as db
        conn = db.get_db()
        row = conn.execute(
            "SELECT password_hash FROM admins WHERE name='admin'"
        ).fetchone()
        conn.close()
        assert row is not None, "No admin user found"
        stored = row['password_hash']
        # Must be a PBKDF2 hash string, never plaintext
        assert stored.startswith('pbkdf2:'), \
            f"FAIL [CRITICAL]: Admin password stored as plaintext: {stored!r}"
        assert len(stored) > 40, \
            "FAIL [CRITICAL]: Password hash too short — likely not properly hashed"
        # Warn (not fail) that the default password is weak — PoC acceptable
        import warnings
        trivial = ['admin', 'admin123', 'password', '1234']
        for pw in trivial:
            if db.verify_password(stored, pw):
                warnings.warn(
                    f"[PRODUCTION RISK]: Default admin password is trivially weak ('{pw}'). "
                    "Change it before any real deployment.",
                    UserWarning
                )


# ===========================================================================
# INFO — Information Disclosure
# ===========================================================================

class TestInformationDisclosure:

    def test_404_does_not_reveal_stack_trace(self, client):
        """INFO-01 [MEDIUM]: 404 pages must not expose internal file paths
        or Python stack traces."""
        c, _, _ = client
        r = c.get('/this/route/does/not/exist')
        body = r.data.lower()
        assert b'traceback' not in body, \
            "FAIL [MEDIUM]: 404 response contains Python traceback"
        assert b'site-packages' not in body, \
            "FAIL [MEDIUM]: 404 response leaks internal path"

    def test_500_does_not_reveal_stack_trace(self, auth_client):
        """INFO-02 [HIGH]: Internal errors must not expose stack traces in
        production mode (debug=False)."""
        import app as flask_app
        assert not flask_app.app.debug, \
            "FAIL [HIGH]: Flask debug mode is ON — stack traces exposed to users"

    def test_error_page_does_not_reveal_db_path(self, auth_client):
        """INFO-03 [MEDIUM]: Error responses must not reveal the database file path."""
        c, _, _ = auth_client
        # Trigger a registration with a duplicate NID to get an error page
        import database as db
        conn = db.get_db()
        conn.execute(
            "INSERT OR IGNORE INTO voters (fname,lname,nid,area,age,enc_hash,enc_data,voted)"
            " VALUES ('X','Y','999999999999','area1',25,'h',?,0)", (b'x',))
        conn.commit()
        conn.close()
        r = c.post('/register/submit', data={
            'firstname': 'X', 'lastname': 'Y', 'birthday': '1990-01-01',
            'gender': 'male', 'permanent': 'addr', 'nid': '999999999999',
            'area': 'area1'
        }, follow_redirects=True)
        assert b'voters.db' not in r.data, \
            "FAIL [MEDIUM]: Error page reveals database file path"


# ===========================================================================
# INP — Input Validation
# ===========================================================================

class TestInputValidation:

    def test_extremely_long_nid_rejected(self, auth_client):
        """INP-01 [LOW]: NID field must reject inputs longer than 12 digits
        to prevent buffer-overflow-like conditions in downstream code."""
        c, _, _ = auth_client
        r = c.post('/register/submit', data={
            'firstname': 'A', 'lastname': 'B', 'birthday': '1990-01-01',
            'gender': 'male', 'permanent': 'addr',
            'nid': '1' * 1000,   # 1000-char NID
            'area': 'area1'
        }, follow_redirects=True)
        assert b'12 digits' in r.data or r.status_code in (302, 400), \
            "FAIL [LOW]: 1000-char NID not rejected"

    def test_candidate_name_max_length(self, auth_client):
        """INP-02 [LOW]: Candidate name must be bounded to prevent oversized
        blockchain entries that could degrade performance."""
        import database as db
        c, _, _ = auth_client
        nid = '555666777888'
        _insert_voter(db.DB_PATH, nid, voted=0)
        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xtest'
        with patch('app.get_result', return_value='Registered'):
            r = c.post('/vote/submit',
                       data={'candidate': 'A' * 10000},
                       follow_redirects=True)
        # Either rejected or truncated — must not crash
        assert r.status_code == 200, \
            "FAIL [LOW]: 10000-char candidate name caused a crash"

    def test_unicode_in_name_fields_handled(self, auth_client):
        """INP-03 [LOW]: Unicode and emoji in name fields must not crash the app."""
        c, _, _ = auth_client
        r = c.post('/register/submit', data={
            'firstname': '测试用户🗳️',
            'lastname': 'Ünïcödé',
            'birthday': '1990-01-01',
            'gender': 'male',
            'permanent': '123 Street',
            'nid': '123456789001',
            'area': 'area1'
        }, follow_redirects=True)
        assert r.status_code == 200, \
            "FAIL [LOW]: Unicode in name fields caused a crash"

    def test_nid_with_special_chars_rejected(self, auth_client):
        """INP-04 [MEDIUM]: NID field must reject non-digit characters including
        special characters that could be used in injection attacks."""
        c, _, _ = auth_client
        for nid in ["'; DROP TABLE voters;--", "../../../etc/passwd", "<script>x</script>"]:
            r = c.post('/register/submit', data={
                'firstname': 'A', 'lastname': 'B', 'birthday': '1990-01-01',
                'gender': 'male', 'permanent': 'addr',
                'nid': nid, 'area': 'area1'
            }, follow_redirects=True)
            assert b'12 digits' in r.data or r.status_code in (302, 400), \
                f"FAIL [MEDIUM]: Malicious NID {nid!r} was not rejected"


# ===========================================================================
# AC — Access Control
# ===========================================================================

class TestAccessControl:

    def test_vote_submit_without_voting_nid_in_session(self, auth_client):
        """AC-01 [HIGH]: vote/submit without a voting_nid in session must redirect,
        not expose an unhandled error or process a phantom vote."""
        c, _, _ = auth_client
        with patch('app.get_result', return_value='Registered'):
            r = c.post('/vote/submit',
                       data={'candidate': 'Attacker'},
                       follow_redirects=False)
        assert r.status_code == 302 or b'session' in r.data.lower() or \
               b'expired' in r.data.lower(), \
            "FAIL [HIGH]: vote/submit without session NID does not gracefully redirect"

    def test_cannot_access_decrypted_uploads_directly(self, auth_client):
        """AC-02 [HIGH]: Decrypted biometric images must not be accessible via
        direct URL — they should be outside the static serving path."""
        c, _, _ = auth_client
        r = c.get('/uploads/decrypted/Registered.png')
        assert r.status_code == 404, \
            "FAIL [HIGH]: Decrypted biometric image accessible via direct URL"

    def test_register_submit_not_accessible_unauthenticated(self, client):
        """AC-03 [CRITICAL]: Registration endpoint must require admin authentication."""
        c, _, _ = client
        r = c.post('/register/submit', data={
            'firstname': 'Evil', 'lastname': 'Hacker',
            'birthday': '1990-01-01', 'gender': 'male',
            'permanent': 'addr', 'nid': '123456789099', 'area': 'area1'
        }, follow_redirects=False)
        assert r.status_code == 302
        assert 'login' in r.headers.get('Location', '').lower(), \
            "FAIL [CRITICAL]: Unauthenticated registration request not redirected to login"


# ===========================================================================
# BLKC — Blockchain persistence & tamper evidence
# ===========================================================================

class TestBlockchainRound2:

    def test_blockchain_survives_module_reload(self, auth_client):
        """BLKC-01 [HIGH]: Votes must persist to the database and survive a
        module reimport (i.e., a server restart)."""
        import database as db
        import blockchain as bc_module

        c, _, _ = auth_client
        nid = '100200300400'
        _insert_voter(db.DB_PATH, nid, voted=0)
        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xpersist'
        with patch('app.get_result', return_value='Registered'):
            c.post('/vote/submit', data={'candidate': 'PersistParty'},
                   follow_redirects=True)

        # Query the DB directly (bypasses in-memory cache)
        conn = sqlite3.connect(bc_module.DB_PATH)
        count = conn.execute(
            "SELECT COUNT(*) FROM blockchain WHERE candidate=?",
            ('PersistParty',)
        ).fetchone()[0]
        conn.close()

        assert count >= 1, \
            "FAIL [HIGH]: Vote not persisted to blockchain DB after submission"

    def test_blockchain_db_path_separate_check(self, auth_client):
        """BLKC-02 [MEDIUM]: Blockchain DB must be queryable and contain the
        genesis block or at least one record after initialization."""
        import blockchain as bc_module
        conn = sqlite3.connect(bc_module.DB_PATH)
        try:
            tables = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
            table_names = [t[0] for t in tables]
            assert 'blockchain' in table_names, \
                "FAIL [MEDIUM]: 'blockchain' table does not exist in blockchain DB"
        finally:
            conn.close()
