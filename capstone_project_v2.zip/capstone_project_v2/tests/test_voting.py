"""
VOTE-01 … VOTE-09  — Vote casting flow & double-vote prevention tests

Government security concern: one citizen, one vote.  Any mechanism that allows
a voter to vote more than once, or to vote without authentication, is a
critical election-integrity failure.
"""
import hashlib
import io
import os
import sqlite3
import threading
from unittest.mock import patch

import pytest
from conftest import register_voter


def _insert_voter(db_path, nid, enc_hash, voted=0):
    """Directly insert a voter row (bypasses Flask layer for unit isolation)."""
    conn = sqlite3.connect(db_path)
    conn.execute(
        '''INSERT OR REPLACE INTO voters
           (fname, lname, nid, area, age, enc_hash, enc_data, voted)
           VALUES ('Test','User',?,?,25,?,?,?)''',
        (nid, 'area1', enc_hash, b'blob', voted),
    )
    conn.commit()
    conn.close()


def _fake_enc_file(enc_hash: str) -> bytes:
    """Return dummy bytes that hash to enc_hash — used to simulate the smart card."""
    # We cannot reverse SHA-256, so we store arbitrary bytes and patch the hasher.
    return b'FAKE_ENC_IMAGE'


class TestVoteUpload:
    def test_non_image_file_rejected(self, auth_client):
        """VOTE-01: Non-image uploads must be refused."""
        c, _, _ = auth_client
        data = {'file': (io.BytesIO(b'not an image'), 'malware.exe')}
        r = c.post('/vote/upload', data=data,
                   content_type='multipart/form-data', follow_redirects=True)
        assert b'authenticate' not in r.data.lower()

    def test_unregistered_smart_card_rejected(self, auth_client):
        """VOTE-02: An enc.jpg whose hash is not in the DB must be rejected."""
        c, tmpdir, uploads = auth_client
        import database as db
        db_path = db.DB_PATH

        fake_img = b'\xff\xd8\xff' + b'\x00' * 100   # minimal JPEG header
        with patch('app.decrypt_uploaded', return_value=('not_registered', None)):
            data = {'file': (io.BytesIO(fake_img), 'enc.jpg')}
            r = c.post('/vote/upload', data=data,
                       content_type='multipart/form-data', follow_redirects=True)
        assert b'not registered' in r.data.lower() or b'error' in r.data.lower()

    def test_already_voted_blocked(self, auth_client):
        """VOTE-03: A voter who has already voted must be blocked."""
        c, _, _ = auth_client
        fake_img = b'\xff\xd8\xff' + b'\x00' * 100
        with patch('app.decrypt_uploaded', return_value=('already_voted', None)):
            data = {'file': (io.BytesIO(fake_img), 'enc.jpg')}
            r = c.post('/vote/upload', data=data,
                       content_type='multipart/form-data', follow_redirects=True)
        assert b'already voted' in r.data.lower() or b'error' in r.data.lower()

    def test_valid_upload_redirects_to_authenticate(self, auth_client):
        """VOTE-04: A valid smart card image redirects to face authentication."""
        c, _, _ = auth_client
        fake_img = b'\xff\xd8\xff' + b'\x00' * 100
        with patch('app.decrypt_uploaded', return_value=('ok', '123456789012')):
            data = {'file': (io.BytesIO(fake_img), 'enc.jpg')}
            r = c.post('/vote/upload', data=data,
                       content_type='multipart/form-data', follow_redirects=False)
        assert r.status_code == 302
        assert 'authenticate' in r.headers.get('Location', '').lower()


class TestVoteCast:
    def test_vote_cast_requires_face_recognition(self, auth_client):
        """VOTE-05 [CRITICAL]: /vote/cast must be unreachable without face match."""
        c, _, _ = auth_client
        with patch('app.get_result', return_value='Unknown'):
            r = c.get('/vote/cast', follow_redirects=False)
        # Must not render the voting page — redirect away
        assert r.status_code == 302 or b'candidate' not in r.data.lower()

    def test_vote_submit_requires_session_nid(self, auth_client):
        """VOTE-06: Submitting vote without session NID must be rejected."""
        c, _, _ = auth_client
        with patch('app.get_result', return_value='Registered'):
            r = c.post('/vote/submit', data={'candidate': 'Party A'},
                       follow_redirects=True)
        assert b'candidate' not in r.data.lower() or b'session' in r.data.lower()

    def test_double_vote_prevented(self, auth_client):
        """VOTE-07 [CRITICAL]: The same NID cannot vote twice."""
        c, tmpdir, uploads = auth_client
        import database as db
        nid = '987654321098'
        _insert_voter(db.DB_PATH, nid, 'somehash', voted=0)

        # First vote
        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xdeadbeef'
        with patch('app.get_result', return_value='Registered'):
            r1 = c.post('/vote/submit', data={'candidate': 'Party A'},
                        follow_redirects=True)
        assert b'successfully' in r1.data.lower() or b'block' in r1.data.lower()

        # Attempt second vote with same NID
        conn = sqlite3.connect(db.DB_PATH)
        voted_flag = conn.execute(
            'SELECT voted FROM voters WHERE nid=?', (nid,)).fetchone()[0]
        conn.close()
        assert voted_flag == 1, "Voter voted flag not set after first vote"

        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xcafebabe'
        with patch('app.get_result', return_value='Registered'):
            r2 = c.post('/vote/submit', data={'candidate': 'Party B'},
                        follow_redirects=True)
        assert b'already' in r2.data.lower() or b'error' in r2.data.lower(), \
            "FAIL [CRITICAL]: Double-vote was not prevented"

    def test_empty_candidate_rejected(self, auth_client):
        """VOTE-08: Submitting an empty candidate name must be rejected."""
        c, tmpdir, _ = auth_client
        import database as db
        nid = '111222333444'
        _insert_voter(db.DB_PATH, nid, 'hashval', voted=0)
        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xabc'
        with patch('app.get_result', return_value='Registered'):
            r = c.post('/vote/submit', data={'candidate': '   '},
                       follow_redirects=True)
        assert b'success' not in r.data.lower()

    def test_concurrent_double_vote_race_condition(self, auth_client):
        """VOTE-09 [HIGH]: Concurrent requests for same NID must not allow two votes.
        Simulates race condition: two threads submit vote simultaneously."""
        import database as db
        nid = '777888999000'
        _insert_voter(db.DB_PATH, nid, 'racehash', voted=0)

        app_obj, _, _ = auth_client[0].application, None, None
        results = []

        def cast_vote(thread_id):
            with app_obj.test_client() as tc:
                tc.post('/login', data={'adminid': 'admin', 'password': 'admin'})
                with tc.session_transaction() as sess:
                    sess['voting_nid'] = nid
                    sess['account'] = f'0xthread{thread_id}'
                with patch('app.get_result', return_value='Registered'):
                    r = tc.post('/vote/submit', data={'candidate': 'PartyX'},
                                follow_redirects=True)
                results.append(r.data)

        # Fire two threads simultaneously
        t1 = threading.Thread(target=cast_vote, args=(1,))
        t2 = threading.Thread(target=cast_vote, args=(2,))
        t1.start(); t2.start()
        t1.join(); t2.join()

        # Check DB — voted flag must be 1 (set exactly once)
        conn = sqlite3.connect(db.DB_PATH)
        voted_flag = conn.execute(
            "SELECT voted FROM voters WHERE nid=?", (nid,)
        ).fetchone()[0]
        conn.close()

        assert voted_flag == 1, "FAIL [HIGH]: voted flag not set after concurrent votes"
        # Only one thread should have received the vote_success page
        success_pages = sum(1 for d in results if b'tx_hash' in d or b'successfully' in d.lower())
        assert success_pages <= 1, (
            f"FAIL [HIGH]: Race condition allowed {success_pages} votes for one NID"
        )
