"""
REG-01 … REG-10  — Voter registration validation tests

Government security concern: only eligible citizens (age ≥ 18, valid NID,
unique per election) may be registered.  Any bypass allows fraudulent enrollment.
"""
import pytest
from conftest import register_voter


class TestRegistrationValidation:
    def test_valid_registration_succeeds(self, auth_client):
        """REG-01: A valid registration stores the voter and redirects."""
        r = register_voter(auth_client)
        assert r.status_code == 200

    def test_duplicate_nid_rejected(self, auth_client):
        """REG-02: Registering the same NID twice must be rejected."""
        register_voter(auth_client, nid='123456789012')
        r = register_voter(auth_client, nid='123456789012')
        assert b'already' in r.data.lower() or b'registered' in r.data.lower()

    def test_underage_voter_rejected(self, auth_client):
        """REG-03 [CRITICAL]: Voters under 18 must be rejected."""
        r = register_voter(auth_client, nid='111111111111', age=17, dob='2010-01-01')
        assert r.status_code == 200
        # Must NOT reach face capture
        assert b'face' not in r.data.lower() or b'biometric' not in r.data.lower()
        assert b'18' in r.data or b'age' in r.data.lower() or b'old' in r.data.lower()

    def test_age_spoofing_blocked(self, auth_client):
        """REG-04 [CRITICAL]: Client-side age field must not be trusted.
        An attacker sends age=25 but DOB of a 10-year-old."""
        c, _, _ = auth_client
        r = c.post('/register/submit', data={
            'firstname': 'Minor',
            'lastname': 'User',
            'birthday': '2015-06-15',   # ~10 years old
            'age': '25',                # spoofed age
            'gender': 'male',
            'permanent': '1 Test Rd',
            'nid': '222222222222',
            'area': 'area1',
        }, follow_redirects=True)
        # Server must compute age from DOB and reject
        assert b'18' in r.data or b'age' in r.data.lower() or b'old' in r.data.lower(), \
            "FAIL [CRITICAL]: Age spoofing succeeded — server trusted client-supplied age"

    def test_nid_must_be_12_digits(self, auth_client):
        """REG-05: NID shorter or non-numeric must be rejected."""
        c, _, _ = auth_client
        bad_nids = ['12345', 'ABCDEFGHIJKL', '123 456 789 01', '']
        for nid in bad_nids:
            r = c.post('/register/submit', data={
                'firstname': 'Test', 'lastname': 'User',
                'birthday': '1990-01-01', 'age': 34,
                'gender': 'male', 'permanent': 'Addr',
                'nid': nid, 'area': 'area1',
            }, follow_redirects=True)
            assert b'face' not in r.data.lower() or b'nid' in r.data.lower() or \
                   b'12' in r.data, f"Invalid NID {nid!r} was accepted"

    def test_missing_required_fields_rejected(self, auth_client):
        """REG-06: Requests with missing required fields are rejected."""
        c, _, _ = auth_client
        r = c.post('/register/submit', data={
            'firstname': '',
            'lastname': 'User',
            'birthday': '1990-01-01',
            'age': 34,
            'gender': 'male',
            'permanent': 'Addr',
            'nid': '123456789013',
            'area': 'area1',
        }, follow_redirects=True)
        assert b'face' not in r.data.lower() or b'required' in r.data.lower()

    def test_invalid_area_rejected(self, auth_client):
        """REG-07: Area parameter must be validated server-side."""
        c, _, _ = auth_client
        r = c.post('/register/submit', data={
            'firstname': 'Test', 'lastname': 'User',
            'birthday': '1990-01-01', 'age': 34,
            'gender': 'male', 'permanent': 'Addr',
            'nid': '333333333333',
            'area': '../../etc/passwd',   # path traversal attempt
        }, follow_redirects=True)
        assert b'face' not in r.data.lower()

    def test_xss_in_name_fields_escaped(self, auth_client):
        """REG-08: HTML characters in name fields must be escaped in responses."""
        c, _, _ = auth_client
        r = c.post('/register/submit', data={
            'firstname': '<script>alert(1)</script>',
            'lastname': 'User',
            'birthday': '1990-01-01', 'age': 34,
            'gender': 'male', 'permanent': 'Addr',
            'nid': '444444444444', 'area': 'area1',
        }, follow_redirects=True)
        assert b'<script>alert(1)</script>' not in r.data, \
            "FAIL: XSS payload reflected unescaped in response"

    def test_unauthenticated_registration_blocked(self, client):
        """REG-09: Registration without admin login must be rejected."""
        c, _, _ = client
        r = c.post('/register/submit', data={
            'firstname': 'Hacker', 'lastname': 'User',
            'birthday': '1990-01-01', 'age': 34,
            'gender': 'male', 'permanent': 'Addr',
            'nid': '555555555555', 'area': 'area1',
        }, follow_redirects=False)
        assert r.status_code == 302
        assert 'login' in r.headers.get('Location', '').lower()

    def test_face_capture_requires_registering_nid_in_session(self, auth_client):
        """REG-10: Face capture page must be unreachable without a pending NID."""
        c, _, _ = auth_client
        r = c.get('/register/face', follow_redirects=False)
        # Should redirect away — no NID in session
        assert r.status_code == 302
