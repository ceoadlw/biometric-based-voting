"""
AUTH-01 … AUTH-07  — Authentication & session management tests

Government security concern: admin accounts are the single point of control.
Any bypass or weak credential storage is a critical finding.
"""
import hashlib
import sqlite3

import pytest
from conftest import sha256


class TestLogin:
    def test_valid_login_redirects_to_menu(self, client):
        """AUTH-01: Correct credentials produce an authenticated session."""
        c, _, _ = client
        r = c.post('/login', data={'adminid': 'admin', 'password': 'admin'},
                   follow_redirects=False)
        assert r.status_code == 302
        assert '/menu' in r.headers['Location']

    def test_wrong_password_rejected(self, client):
        """AUTH-02: Wrong password must not authenticate."""
        c, _, _ = client
        r = c.post('/login', data={'adminid': 'admin', 'password': 'wrongpassword'},
                   follow_redirects=True)
        assert r.status_code == 200
        assert b'Invalid' in r.data or b'invalid' in r.data.lower()

    def test_empty_credentials_rejected(self, client):
        """AUTH-03: Empty fields must not bypass login."""
        c, _, _ = client
        r = c.post('/login', data={'adminid': '', 'password': ''},
                   follow_redirects=True)
        assert b'menu' not in r.data.lower() or r.status_code != 200

    def test_unauthenticated_menu_redirects_to_login(self, client):
        """AUTH-04: Protected routes require authentication."""
        c, _, _ = client
        r = c.get('/menu', follow_redirects=False)
        assert r.status_code == 302
        assert 'login' in r.headers['Location'].lower()

    def test_logout_clears_session(self, auth_client):
        """AUTH-05: After logout, protected routes must redirect to login."""
        c, _, _ = auth_client
        c.get('/logout')
        r = c.get('/menu', follow_redirects=False)
        assert r.status_code == 302

    def test_sql_injection_in_login(self, client):
        """AUTH-06 [CRITICAL]: SQL injection in admin ID must not grant access."""
        c, _, _ = client
        payloads = [
            ("' OR '1'='1", "password"),
            ("admin'--", "anything"),
            ("' UNION SELECT 1,2--", "x"),
            ("admin' /*", "*/"),
        ]
        for adminid, password in payloads:
            r = c.post('/login', data={'adminid': adminid, 'password': password},
                       follow_redirects=False)
            assert r.status_code != 302 or '/menu' not in (r.headers.get('Location') or ''), \
                f"SQL injection succeeded with payload: {adminid!r}"

    def test_password_not_stored_in_plaintext(self, app_instance):
        """AUTH-07 [CRITICAL]: Passwords must never be stored in plaintext."""
        import database as db
        db_path = db.DB_PATH
        conn = sqlite3.connect(db_path)
        rows = conn.execute('SELECT password_hash FROM admins').fetchall()
        conn.close()
        for (pw_hash,) in rows:
            assert pw_hash != 'admin123', "Password stored as plaintext!"
            assert len(pw_hash) >= 32, "Password hash too short — not properly hashed"


class TestPasswordSecurity:
    def test_password_uses_salted_hash(self, app_instance):
        """AUTH-08 [HIGH]: SHA-256 without salt is vulnerable to rainbow tables.
        Passwords should use bcrypt or argon2."""
        import database as db
        conn = sqlite3.connect(db.DB_PATH)
        rows = conn.execute('SELECT password_hash FROM admins').fetchall()
        conn.close()
        raw_sha256 = hashlib.sha256('admin123'.encode()).hexdigest()
        for (pw_hash,) in rows:
            assert pw_hash != raw_sha256, (
                "FAIL [HIGH]: Password hashed with raw SHA-256 (no salt). "
                "Vulnerable to rainbow table attacks. Use bcrypt or argon2."
            )
