"""
SEC-01 … SEC-10  — Security-specific tests

Government security concern: the voting system is a high-value target.
These tests cover OWASP Top-10 categories most relevant to a web-based
election system: injection, broken auth, sensitive data exposure,
insecure direct object references, and security misconfiguration.
"""
import io

import pytest


class TestCSRF:
    def test_login_lacks_csrf_token(self, client):
        """SEC-01 [HIGH]: Login form has no CSRF protection.
        An adversary can trick an admin into submitting the logout form
        or triggering other state-changing actions via cross-site request forgery."""
        c, _, _ = client
        # With CSRF enforcement the request should be rejected without token;
        # without enforcement it succeeds — we flag this as a finding.
        r = c.post('/login', data={'adminid': 'admin', 'password': 'admin'},
                   follow_redirects=False)
        # If this succeeds without a CSRF token, that is the vulnerability.
        assert r.status_code == 302, (
            "Login should succeed (CSRF not yet enforced) — "
            "but this test documents the missing control."
        )
        # The real assertion: there should be a CSRF token in the response HTML
        r2 = c.get('/login')
        assert b'csrf' in r2.data.lower() or b'_token' in r2.data.lower(), \
            "FAIL [HIGH]: Login form contains no CSRF token"


class TestFileUpload:
    def test_oversized_upload_rejected(self, auth_client):
        """SEC-02 [MEDIUM]: Uploads larger than the allowed limit must be rejected.
        Without MAX_CONTENT_LENGTH a 1 GB file would be accepted (DoS vector)."""
        import app as flask_app
        assert flask_app.app.config.get('MAX_CONTENT_LENGTH') is not None, \
            "FAIL [MEDIUM]: MAX_CONTENT_LENGTH not set — large file uploads accepted"

    def test_svg_upload_rejected(self, auth_client):
        """SEC-03: SVG files (potential XSS carrier) must not be accepted."""
        c, _, _ = auth_client
        svg = b'<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'
        data = {'file': (io.BytesIO(svg), 'evil.svg')}
        r = c.post('/vote/upload', data=data,
                   content_type='multipart/form-data', follow_redirects=True)
        assert b'authenticate' not in r.data.lower()

    def test_double_extension_upload_rejected(self, auth_client):
        """SEC-04: Files named *.php.jpg or *.aspx.png must be rejected or handled safely."""
        c, _, _ = auth_client
        from unittest.mock import patch
        data = {'file': (io.BytesIO(b'\xff\xd8\xff'), 'shell.php.jpg')}
        # The saved filename must NOT include .php
        with patch('app.decrypt_uploaded', return_value=('not_registered', None)):
            r = c.post('/vote/upload', data=data,
                       content_type='multipart/form-data', follow_redirects=True)
        # Simply ensure we don't crash; the saved file is always renamed to enc.jpg
        assert r.status_code == 200


class TestSessionSecurity:
    def test_session_nid_cleared_after_vote(self, auth_client):
        """SEC-05 [HIGH]: voting_nid must be removed from session after voting.
        Leaving it in allows a second vote attempt in the same browser session."""
        import database as db
        import sqlite3
        from unittest.mock import patch

        c, _, _ = auth_client
        nid = '112233445566'
        conn = sqlite3.connect(db.DB_PATH)
        conn.execute(
            "INSERT INTO voters (fname,lname,nid,area,age,enc_hash,enc_data,voted) "
            "VALUES ('A','B',?,?,25,'h',?,0)", (nid, 'area1', b'x'))
        conn.commit()
        conn.close()

        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xsec'
        with patch('app.get_result', return_value='Registered'):
            c.post('/vote/submit', data={'candidate': 'PartyA'}, follow_redirects=True)

        with c.session_transaction() as sess:
            assert 'voting_nid' not in sess, \
                "FAIL [HIGH]: voting_nid remains in session after vote cast"

    def test_account_cleared_after_vote(self, auth_client):
        """SEC-06: account must be removed from session after voting."""
        import database as db
        import sqlite3
        from unittest.mock import patch

        c, _, _ = auth_client
        nid = '998877665544'
        conn = sqlite3.connect(db.DB_PATH)
        conn.execute(
            "INSERT INTO voters (fname,lname,nid,area,age,enc_hash,enc_data,voted) "
            "VALUES ('C','D',?,?,25,'h2',?,0)", (nid, 'area1', b'y'))
        conn.commit()
        conn.close()

        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xsec2'
        with patch('app.get_result', return_value='Registered'):
            c.post('/vote/submit', data={'candidate': 'PartyB'}, follow_redirects=True)

        with c.session_transaction() as sess:
            assert 'account' not in sess, \
                "FAIL: account remains in session after vote cast"


class TestInputSanitisation:
    def test_candidate_xss_not_reflected(self, auth_client):
        """SEC-07: XSS in candidate name must be escaped in all output pages."""
        import database as db
        import sqlite3
        from unittest.mock import patch
        import blockchain as bc

        c, _, _ = auth_client
        nid = '556677889900'
        conn = sqlite3.connect(db.DB_PATH)
        conn.execute(
            "INSERT INTO voters (fname,lname,nid,area,age,enc_hash,enc_data,voted) "
            "VALUES ('E','F',?,?,25,'h3',?,0)", (nid, 'area1', b'z'))
        conn.commit()
        conn.close()

        with c.session_transaction() as sess:
            sess['voting_nid'] = nid
            sess['account'] = '0xxss'
        with patch('app.get_result', return_value='Registered'):
            c.post('/vote/submit',
                   data={'candidate': '<script>alert("xss")</script>'},
                   follow_redirects=True)

        r = c.get('/blockchain', follow_redirects=True)
        assert b'<script>alert("xss")</script>' not in r.data, \
            "FAIL [HIGH]: XSS payload reflected unescaped on blockchain explorer"

    def test_blockchain_search_sql_injection(self, auth_client):
        """SEC-08: Blockchain tx-hash search must use parameterised queries.
        SQL injection payloads must not crash the server or leak DB schema rows."""
        c, _, _ = auth_client
        import blockchain as bc

        # Insert one real block so we can confirm leakage would be detectable
        block = bc.add_vote('0xlegit', 'LegitParty')

        payloads = [
            "' OR '1'='1",
            "'; DROP TABLE blockchain;--",
            "' UNION SELECT name,sql,3,4,5,6,7,8 FROM sqlite_master--",
            "1' OR '1'='1' --",
        ]
        for payload in payloads:
            r = c.get(f'/blockchain?tx={payload}', follow_redirects=True)
            assert r.status_code == 200, \
                f"Server crashed on payload: {payload!r}"
            # The searched_block section should NOT appear for injection payloads
            # (no real block has a tx_hash matching these strings)
            assert b'search result' not in r.data.lower(), \
                f"FAIL [CRITICAL]: SQL injection returned a block row for payload: {payload!r}"


class TestAccessControl:
    def test_all_protected_routes_require_auth(self, client):
        """SEC-09: Every post-login route must redirect to /login when unauthenticated."""
        c, _, _ = client
        protected = [
            '/menu', '/register', '/register/face', '/register/complete',
            '/vote', '/vote/authenticate', '/vote/cast',
            '/blockchain', '/results',
        ]
        for route in protected:
            r = c.get(route, follow_redirects=False)
            assert r.status_code == 302, \
                f"Route {route} reachable without login (status {r.status_code})"
            assert 'login' in r.headers.get('Location', '').lower(), \
                f"Route {route} does not redirect to login"

    def test_vote_cast_not_accessible_without_voting_session(self, auth_client):
        """SEC-10: /vote/cast must require a valid voting session (not just admin login)."""
        c, _, _ = auth_client
        from unittest.mock import patch
        with patch('app.get_result', return_value='Registered'):
            r = c.get('/vote/cast', follow_redirects=False)
        # voting_nid is not in session → must redirect away
        assert r.status_code == 302
