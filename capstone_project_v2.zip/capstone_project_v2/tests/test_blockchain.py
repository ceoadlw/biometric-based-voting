"""
CHAIN-01 … CHAIN-06  — Blockchain integrity tests

Government security concern: the vote ledger must be tamper-evident.
Any ability to alter a recorded vote silently breaks election integrity.
"""
import sqlite3

import pytest
import blockchain as bc


@pytest.fixture(autouse=True)
def isolated_db(app_instance, monkeypatch):
    """Point blockchain module at the test DB."""
    import database as db
    monkeypatch.setattr(bc, 'DB_PATH', db.DB_PATH)
    yield


class TestBlockchainIntegrity:
    def test_add_vote_returns_valid_block(self, app_instance):
        """CHAIN-01: add_vote must return a dict with all required fields."""
        block = bc.add_vote('0xabc123', 'PartyA')
        assert 'tx_hash' in block
        assert 'block_hash' in block
        assert 'prev_hash' in block
        assert block['candidate'] == 'PartyA'
        assert block['account'] == '0xabc123'

    def test_chain_grows_with_each_vote(self, app_instance):
        """CHAIN-02: Each vote appends a new block with incrementing index."""
        b1 = bc.add_vote('0x001', 'PartyA')
        b2 = bc.add_vote('0x002', 'PartyB')
        assert b2['index'] == b1['index'] + 1

    def test_chain_is_valid_after_votes(self, app_instance):
        """CHAIN-03: verify_chain() must pass on an unmodified chain."""
        bc.add_vote('0xaa', 'PartyA')
        bc.add_vote('0xbb', 'PartyB')
        bc.add_vote('0xcc', 'PartyA')
        assert bc.verify_chain() is True

    def test_tampered_candidate_detected(self, app_instance):
        """CHAIN-04 [CRITICAL]: Directly editing a vote in the DB must fail verification."""
        import database as db
        bc.add_vote('0xta', 'PartyA')
        bc.add_vote('0xtb', 'PartyB')

        conn = sqlite3.connect(db.DB_PATH)
        conn.execute("UPDATE blockchain SET candidate='PartyC' WHERE account='0xta'")
        conn.commit()
        conn.close()

        assert bc.verify_chain() is False, \
            "FAIL [CRITICAL]: Tampered vote not detected by chain verification"

    def test_tampered_prev_hash_detected(self, app_instance):
        """CHAIN-05 [CRITICAL]: Altering a block's prev_hash must fail verification."""
        import database as db
        bc.add_vote('0x11', 'PartyA')
        bc.add_vote('0x22', 'PartyB')

        conn = sqlite3.connect(db.DB_PATH)
        conn.execute(
            "UPDATE blockchain SET prev_hash='deadbeef' WHERE block_index=2"
        )
        conn.commit()
        conn.close()

        assert bc.verify_chain() is False

    def test_lookup_by_tx_hash(self, app_instance):
        """CHAIN-06: get_block_by_tx must return the correct block."""
        block = bc.add_vote('0xfind', 'PartyZ')
        found = bc.get_block_by_tx(block['tx_hash'])
        assert found is not None
        assert found['candidate'] == 'PartyZ'
        assert found['account'] == '0xfind'

    def test_nonexistent_tx_returns_none(self, app_instance):
        """CHAIN-07: Querying a missing tx_hash must return None, not raise."""
        result = bc.get_block_by_tx('0' * 64)
        assert result is None

    def test_results_sorted_by_votes_desc(self, app_instance):
        """CHAIN-08: get_results() must return candidates in descending vote order."""
        bc.add_vote('0xa', 'PartyA')
        bc.add_vote('0xb', 'PartyB')
        bc.add_vote('0xc', 'PartyA')   # PartyA has 2, PartyB has 1
        results = bc.get_results()
        assert results[0]['candidate'] == 'PartyA'
        assert results[0]['votes'] == 2

    def test_genesis_block_has_zero_prev_hash(self, app_instance):
        """CHAIN-09: First block's prev_hash must be the 64-zero genesis sentinel."""
        block = bc.add_vote('0xfirst', 'PartyA')
        assert block['prev_hash'] == '0' * 64

    def test_account_generation_is_unique(self, app_instance):
        """CHAIN-10: generate_account() must not produce collisions."""
        accounts = {bc.generate_account() for _ in range(1000)}
        assert len(accounts) == 1000, "Account collision detected"
