"""
CRYPTO-01 … CRYPTO-06  — Cryptographic module tests

Government security concern: the biometric template protection algorithm
must be a true round-trip (encrypt → decrypt → identical image) and the
chaos sequences must be non-trivially random (no short cycles).
"""
import os
import sys
import tempfile

import numpy as np
import pytest

ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, ROOT)

from crypto.dna_base import DNA
from crypto.key_gen import (
    compute_image_key,
    dna_decode_channels,
    dna_encode_channels,
    dna_xor,
    scramble_forward,
    scramble_inverse,
    sequence_to_permutation,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_test_image(path: str, w=8, h=8):
    """Write a small synthetic PNG using only stdlib (no PIL)."""
    import zlib, struct

    def png_chunk(ctype, data):
        c = struct.pack('>I', len(data)) + ctype + data
        return c + struct.pack('>I', zlib.crc32(c[4:]) & 0xFFFFFFFF)

    raw_rows = b''
    for _ in range(h):
        row = b'\x00' + bytes([np.random.randint(0, 256) for _ in range(w * 3)])
        raw_rows += row
    compressed = zlib.compress(raw_rows)

    png = (
        b'\x89PNG\r\n\x1a\n'
        + png_chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
        + png_chunk(b'IDAT', compressed)
        + png_chunk(b'IEND', b'')
    )
    with open(path, 'wb') as f:
        f.write(png)


def _random_channel(h=8, w=8):
    return np.asmatrix(
        np.random.randint(0, 256, (h, w), dtype=np.uint8)
    )


# ---------------------------------------------------------------------------
# DNA encoding / decoding
# ---------------------------------------------------------------------------

class TestDNAEncoding:
    def test_encode_decode_roundtrip(self):
        """CRYPTO-01: DNA encode followed by decode must return the original channel."""
        b = _random_channel()
        g = _random_channel()
        r = _random_channel()
        b_enc, g_enc, r_enc = dna_encode_channels(b, g, r)
        b_dec, g_dec, r_dec = dna_decode_channels(b_enc, g_enc, r_enc)
        np.testing.assert_array_equal(np.array(b, dtype=np.uint8), b_dec,
                                       err_msg="Blue channel round-trip failed")
        np.testing.assert_array_equal(np.array(g, dtype=np.uint8), g_dec,
                                       err_msg="Green channel round-trip failed")
        np.testing.assert_array_equal(np.array(r, dtype=np.uint8), r_dec,
                                       err_msg="Red channel round-trip failed")

    def test_xor_is_self_inverse(self):
        """CRYPTO-02: DNA XOR with same key twice must return original value."""
        b = _random_channel()
        g = _random_channel()
        r = _random_channel()
        mk = _random_channel()   # key matrix (same shape, uint8)

        b_enc, g_enc, r_enc = dna_encode_channels(b, g, r)
        mk_enc, _, _ = dna_encode_channels(mk, mk, mk)

        b_xor, g_xor, r_xor = dna_xor(b_enc, g_enc, r_enc, mk_enc)
        b_back, g_back, r_back = dna_xor(b_xor, g_xor, r_xor, mk_enc)

        # After double XOR the DNA strings must equal the originals
        np.testing.assert_array_equal(b_enc, b_back,
                                       err_msg="XOR not self-inverse on blue channel")
        np.testing.assert_array_equal(g_enc, g_back,
                                       err_msg="XOR not self-inverse on green channel")
        np.testing.assert_array_equal(r_enc, r_back,
                                       err_msg="XOR not self-inverse on red channel")

    def test_dna_table_completeness(self):
        """CRYPTO-03: Every two-nucleotide pair must have an XOR entry in the table."""
        nucleotides = ['A', 'T', 'G', 'C']
        for a in nucleotides:
            for b in nucleotides:
                key = a + b
                assert key in DNA, f"Missing DNA XOR entry: {key}"
                assert DNA[key] in nucleotides, f"Invalid XOR result for {key}"


# ---------------------------------------------------------------------------
# Scrambling (permutation)
# ---------------------------------------------------------------------------

class TestScrambling:
    def _make_permutation(self, size):
        """Return a valid permutation index array of given size."""
        perm = np.arange(size, dtype=np.uint32)
        np.random.shuffle(perm)
        return perm

    def test_scramble_roundtrip(self):
        """CRYPTO-04: scramble_forward followed by scramble_inverse must recover original."""
        h, w_dna = 4, 16   # h rows, w_dna DNA columns
        b = np.chararray((h, w_dna)); b[:] = 'A'
        g = np.chararray((h, w_dna)); g[:] = 'T'
        r = np.chararray((h, w_dna)); r[:] = 'G'

        # Fill with varied values
        nucleotides = ['A', 'T', 'G', 'C']
        for i in range(h):
            for j in range(w_dna):
                b[i, j] = nucleotides[(i * w_dna + j) % 4]
                g[i, j] = nucleotides[(i * w_dna + j + 1) % 4]
                r[i, j] = nucleotides[(i * w_dna + j + 2) % 4]

        b = b.astype(str); g = g.astype(str); r = r.astype(str)

        size = h * w_dna
        fx = self._make_permutation(size)
        fy = self._make_permutation(size)
        fz = self._make_permutation(size)

        # forward: scramble(fx,fy,fz, b, r, g) — note r/g swap as in encrypt.py
        b_s, g_s, r_s = scramble_forward(fx, fy, fz, b, r, g)
        # inverse: should recover b_xor, g_xor, r_xor from (b_s, g_s, r_s)
        b_rec, g_rec, r_rec = scramble_inverse(fx, fy, fz, b_s, g_s, r_s)

        np.testing.assert_array_equal(b, b_rec,
                                       err_msg="FAIL [CRYPTO-04]: Blue channel not recovered after scramble round-trip")
        # scramble_forward(fx,fy,fz, b, r, g) internally uses gx=g (3rd arg) and rx=r (2nd arg)
        # so g_rec recovers the 3rd input (test's g) and r_rec recovers the 2nd input (test's r)
        np.testing.assert_array_equal(g, g_rec,
                                       err_msg="FAIL [CRYPTO-04]: Green channel not recovered after scramble round-trip")
        np.testing.assert_array_equal(r, r_rec,
                                       err_msg="FAIL [CRYPTO-04]: Red channel not recovered after scramble round-trip")


# ---------------------------------------------------------------------------
# Key derivation
# ---------------------------------------------------------------------------

class TestKeyDerivation:
    def test_same_image_same_key(self):
        """CRYPTO-05: Two identical images must produce the same key."""
        with tempfile.TemporaryDirectory() as d:
            p1 = os.path.join(d, 'img1.png')
            p2 = os.path.join(d, 'img2.png')
            _make_test_image(p1, w=8, h=8)
            import shutil; shutil.copy(p1, p2)
            k1, _, _ = compute_image_key(p1)
            k2, _, _ = compute_image_key(p2)
            assert k1 == k2

    def test_different_images_different_keys(self):
        """CRYPTO-06: Different images must (with overwhelming probability) differ in key."""
        with tempfile.TemporaryDirectory() as d:
            np.random.seed(42)
            p1 = os.path.join(d, 'img1.png')
            np.random.seed(99)
            p2 = os.path.join(d, 'img2.png')
            _make_test_image(p1, w=8, h=8)
            np.random.seed(100)
            _make_test_image(p2, w=8, h=8)
            k1, _, _ = compute_image_key(p1)
            k2, _, _ = compute_image_key(p2)
            assert k1 != k2, "Different images produced identical keys (collision)"
