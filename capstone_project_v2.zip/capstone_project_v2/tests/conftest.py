"""
Shared fixtures for the e-voting test suite.

Heavy hardware dependencies (webcam, face_recognition, scipy) are mocked so
tests run on any CI/CD machine without physical hardware.
"""
import hashlib
import os
import sys
import tempfile
from unittest.mock import MagicMock, patch

import pytest

# Ensure project root is importable
ROOT = os.path.dirname(os.path.dirname(__file__))
sys.path.insert(0, ROOT)


# ---------------------------------------------------------------------------
# Patch heavy modules before app is imported
# ---------------------------------------------------------------------------
def _make_mock_modules():
    """Return a dict of lightweight stubs for hardware-dependent modules."""
    cv2 = MagicMock()
    cv2.VideoCapture.return_value.__enter__ = lambda s: s
    cv2.VideoCapture.return_value.__exit__ = MagicMock(return_value=False)
    cv2.data.haarcascades = ''
    cv2.CascadeClassifier.return_value.detectMultiScale.return_value = []
    cv2.imencode.return_value = (True, MagicMock(tobytes=lambda: b'\xff\xd8\xff'))

    face_recognition = MagicMock()
    scipy = MagicMock()
    # Keep numpy real
    return {
        'cv2': cv2,
        'face_recognition': face_recognition,
        'scipy': scipy,
        'scipy.integrate': scipy.integrate,
    }


_mocks = _make_mock_modules()
for mod, stub in _mocks.items():
    sys.modules.setdefault(mod, stub)


# ---------------------------------------------------------------------------
# App fixture
# ---------------------------------------------------------------------------
@pytest.fixture()
def app_instance():
    """Create a fresh Flask app with an isolated SQLite DB for each test."""
    import database as db

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, 'test.db')
        uploads = {k: os.path.join(tmpdir, k) for k in
                   ('faces', 'encrypted', 'encrypted_upload', 'decrypted')}
        for d in uploads.values():
            os.makedirs(d)

        # Patch DB path and upload paths before importing app
        import database
        original_db_path = database.DB_PATH
        database.DB_PATH = db_path

        import app as flask_app
        original_uploads = flask_app.UPLOADS.copy()
        original_face   = flask_app.FACE_PATH
        original_enc    = flask_app.ENC_PATH
        original_enc_up = flask_app.ENC_UPLOAD
        original_dec    = flask_app.DEC_PATH

        flask_app.UPLOADS       = uploads
        flask_app.FACE_PATH     = os.path.join(uploads['faces'],            'xyz.png')
        flask_app.ENC_PATH      = os.path.join(uploads['encrypted'],        'enc.jpg')
        flask_app.ENC_UPLOAD    = os.path.join(uploads['encrypted_upload'], 'enc.jpg')
        flask_app.DEC_PATH      = os.path.join(uploads['decrypted'],        'Registered.png')

        db.init_db()

        flask_app.app.config['TESTING'] = True
        flask_app.app.config['SECRET_KEY'] = 'test-secret'
        flask_app.app.config['WTF_CSRF_ENABLED'] = False

        yield flask_app.app, tmpdir, uploads

        # Restore
        database.DB_PATH        = original_db_path
        flask_app.UPLOADS       = original_uploads
        flask_app.FACE_PATH     = original_face
        flask_app.ENC_PATH      = original_enc
        flask_app.ENC_UPLOAD    = original_enc_up
        flask_app.DEC_PATH      = original_dec


@pytest.fixture()
def client(app_instance):
    app, tmpdir, uploads = app_instance
    with app.test_client() as c:
        yield c, tmpdir, uploads


@pytest.fixture()
def auth_client(client):
    """A test client already logged in as admin."""
    c, tmpdir, uploads = client
    c.post('/login', data={'adminid': 'admin', 'password': 'admin'})
    yield c, tmpdir, uploads


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def sha256(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def register_voter(auth_client_fixture, nid='123456789012', area='area1',
                   fname='Test', age=25, dob='1999-01-01'):
    """POST a valid registration form."""
    c, tmpdir, uploads = auth_client_fixture
    return c.post('/register/submit', data={
        'firstname': fname,
        'lastname': 'User',
        'birthday': dob,
        'age': age,
        'gender': 'male',
        'permanent': '123 Test St',
        'nid': nid,
        'area': area,
    }, follow_redirects=True)
