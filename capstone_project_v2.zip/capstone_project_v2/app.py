"""
Decentralized E-Voting — Flask Application
==========================================
Single-server replacement for the original PHP + Python + MySQL stack.

Run:  python app.py
      Then open http://localhost:5000
      Default admin: username=admin  password=admin123
"""
import os
import secrets
from datetime import date

from flask import (
    Flask,
    Response,
    abort,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)

import blockchain as bc
import database as db
from crypto.encrypt import encrypt_face
from crypto.decrypt import decrypt_uploaded
from vision.capture import capture_face, capture_frame_jpeg, stream_frames
from vision.recognize import recognition_stream, get_result, reset_result

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.secret_key = secrets.token_hex(32)   # regenerated each restart; fine for PoC
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5 MB upload limit
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

BASE_DIR = os.path.dirname(__file__)
UPLOADS = {
    'faces':            os.path.join(BASE_DIR, 'uploads', 'faces'),
    'encrypted':        os.path.join(BASE_DIR, 'uploads', 'encrypted'),
    'encrypted_upload': os.path.join(BASE_DIR, 'uploads', 'encrypted_upload'),
    'decrypted':        os.path.join(BASE_DIR, 'uploads', 'decrypted'),
}

FACE_PATH   = os.path.join(UPLOADS['faces'],            'xyz.png')
ENC_PATH    = os.path.join(UPLOADS['encrypted'],        'enc.jpg')
ENC_UPLOAD  = os.path.join(UPLOADS['encrypted_upload'], 'enc.jpg')
DEC_PATH    = os.path.join(UPLOADS['decrypted'],        'Registered.png')


# ---------------------------------------------------------------------------
# CSRF protection
# ---------------------------------------------------------------------------
def _get_csrf_token() -> str:
    if '_csrf_token' not in session:
        session['_csrf_token'] = secrets.token_hex(32)
    return session['_csrf_token']

app.jinja_env.globals['csrf_token'] = _get_csrf_token

@app.before_request
def _csrf_protect():
    if app.config.get('TESTING'):
        return
    if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
        token = (request.form.get('_csrf_token')
                 or request.headers.get('X-CSRF-Token', ''))
        stored = session.get('_csrf_token', '')
        if not stored or not secrets.compare_digest(stored, token):
            abort(403)


@app.after_request
def _security_headers(response):
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    return response


# ---------------------------------------------------------------------------
# Auth helper
# ---------------------------------------------------------------------------
def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('admin'):
            flash('Please log in first.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


# ---------------------------------------------------------------------------
# Admin auth
# ---------------------------------------------------------------------------
@app.route('/')
def index():
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form.get('adminid', '').strip()
        password = request.form.get('password', '')
        conn = db.get_db()
        row = conn.execute(
            'SELECT id, password_hash FROM admins WHERE name = ?',
            (name,),
        ).fetchone()
        conn.close()

        # Always run verify_password — prevents timing oracle even when user not found
        stored = row['password_hash'] if row else db._DUMMY_HASH
        match = db.verify_password(stored, password)   # always executes full PBKDF2
        if row and match:
            session.clear()          # prevent session fixation
            session['admin'] = name
            return redirect(url_for('menu'))
        flash('Invalid credentials.', 'error')
    return render_template('admin_login.html')


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))


# ---------------------------------------------------------------------------
# Home / menu
# ---------------------------------------------------------------------------
@app.route('/menu')
@login_required
def menu():
    return render_template('menu.html')


# ---------------------------------------------------------------------------
# Voter registration
# ---------------------------------------------------------------------------
@app.route('/register')
@login_required
def register():
    return render_template('area_selection.html')


@app.route('/register/form')
@login_required
def register_form():
    area = request.args.get('area', '')
    if area not in ('area1', 'area2', 'area3'):
        flash('Please select a valid area.', 'error')
        return redirect(url_for('register'))
    return render_template('reg_form.html', area=area)


def _compute_age(dob_str: str) -> int:
    """Return age in whole years from a YYYY-MM-DD date string, or -1 on error."""
    try:
        born = date.fromisoformat(dob_str)
        today = date.today()
        return today.year - born.year - ((today.month, today.day) < (born.month, born.day))
    except (ValueError, TypeError):
        return -1


@app.route('/register/submit', methods=['POST'])
@login_required
def register_submit():
    fname  = request.form.get('firstname', '').strip()
    lname  = request.form.get('lastname', '').strip()
    dob    = request.form.get('birthday', '')
    gender = request.form.get('gender', '')
    addr   = request.form.get('permanent', '').strip()
    nid    = request.form.get('nid', '').strip()
    area   = request.form.get('area', '')

    # Validation
    if not all([fname, lname, nid, area]):
        flash('All required fields must be filled.', 'error')
        return redirect(url_for('register_form', area=area))
    if area not in ('area1', 'area2', 'area3'):
        flash('Invalid area selected.', 'error')
        return redirect(url_for('register'))
    if len(nid) != 12 or not nid.isdigit():
        flash('NID must be exactly 12 digits.', 'error')
        return redirect(url_for('register_form', area=area))
    age = _compute_age(dob)
    if age < 18:
        flash('Voter must be at least 18 years old.', 'error')
        return redirect(url_for('register_form', area=area))

    conn = db.get_db()
    existing = conn.execute(
        'SELECT id FROM voters WHERE nid = ?', (nid,)
    ).fetchone()

    if existing:
        conn.close()
        return render_template('error.html',
                               message='This NID is already registered.',
                               back_url=url_for('menu'))

    conn.execute(
        '''INSERT INTO voters (fname, lname, nid, area, age, dob, gender, address)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
        (fname, lname, nid, area, age, dob, gender, addr),
    )
    conn.commit()
    conn.close()

    # Store NID in session so the face capture step knows who to update
    session['registering_nid'] = nid
    flash(f'Personal details saved. Now register your face, {fname}.', 'success')
    return redirect(url_for('face_capture'))


@app.route('/register/face')
@login_required
def face_capture():
    if not session.get('registering_nid'):
        flash('Start registration from the beginning.', 'error')
        return redirect(url_for('register'))
    return render_template('face_capture.html')


@app.route('/register/face/stream')
@login_required
def face_stream():
    """MJPEG stream for the face capture preview."""
    def gen():
        for frame in stream_frames():
            yield (
                b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n'
                + frame
                + b'\r\n\r\n'
            )
    return Response(gen(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/register/face/capture', methods=['POST'])
@login_required
def do_capture_face():
    """Capture one frame, save the face crop, then encrypt it."""
    nid = session.get('registering_nid')
    if not nid:
        return jsonify({'status': 'error', 'message': 'Session expired.'}), 400

    saved = capture_face(FACE_PATH)
    if not saved:
        return jsonify({'status': 'error', 'message': 'No face detected. Try again.'}), 400

    # Encrypt the captured face and persist to DB
    conn = db.get_db()
    try:
        enc_hash = encrypt_face(FACE_PATH, ENC_PATH, nid, conn)
    except Exception as e:
        conn.close()
        return jsonify({'status': 'error', 'message': str(e)}), 500
    conn.close()

    session.pop('registering_nid', None)
    return jsonify({'status': 'ok', 'enc_hash': enc_hash})


@app.route('/register/complete')
@login_required
def register_complete():
    return render_template('reg_success.html')


# ---------------------------------------------------------------------------
# Vote casting
# ---------------------------------------------------------------------------
@app.route('/vote')
@login_required
def vote_upload():
    return render_template('vote_upload.html')


@app.route('/vote/upload', methods=['POST'])
@login_required
def vote_upload_submit():
    if 'file' not in request.files:
        flash('No file selected.', 'error')
        return redirect(url_for('vote_upload'))

    f = request.files['file']
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in ('.jpg', '.jpeg', '.png'):
        flash('Only JPG/PNG images are accepted.', 'error')
        return redirect(url_for('vote_upload'))

    f.save(ENC_UPLOAD)

    conn = db.get_db()
    status, nid = decrypt_uploaded(ENC_UPLOAD, DEC_PATH, conn)
    conn.close()

    if status == 'not_registered':
        return render_template('error.html',
                               message='This smart card is not registered.',
                               back_url=url_for('vote_upload'))
    if status == 'already_voted':
        return render_template('error.html',
                               message='This voter has already cast their vote.',
                               back_url=url_for('menu'))

    # Decryption succeeded — store NID in session for the voting step
    session['voting_nid'] = nid
    reset_result()
    return redirect(url_for('authenticate'))


@app.route('/vote/authenticate')
@login_required
def authenticate():
    if not session.get('voting_nid'):
        flash('Please upload your encrypted image first.', 'error')
        return redirect(url_for('vote_upload'))
    return render_template('authenticate.html')


@app.route('/vote/video_feed')
@login_required
def video_feed():
    """MJPEG stream for the face recognition stage."""
    return Response(
        recognition_stream(UPLOADS['decrypted']),
        mimetype='multipart/x-mixed-replace; boundary=frame',
    )


@app.route('/vote/check_face')
@login_required
def check_face():
    """Polled by the frontend to know when the face is recognised."""
    return jsonify({'result': get_result()})


@app.route('/vote/cast')
@login_required
def vote_cast():
    if get_result() != 'Registered':
        flash('Face not recognised. Please authenticate first.', 'error')
        return redirect(url_for('authenticate'))
    if not session.get('voting_nid'):
        flash('Session expired.', 'error')
        return redirect(url_for('vote_upload'))
    account = bc.generate_account()
    session['account'] = account
    return render_template('vote_cast.html', account=account)


@app.route('/vote/submit', methods=['POST'])
@login_required
def vote_submit():
    nid = session.get('voting_nid')
    account = session.get('account')
    candidate = request.form.get('candidate', '').strip()

    if not nid or not account:
        flash('Session expired.', 'error')
        return redirect(url_for('vote_upload'))
    if not candidate:
        flash('Please enter a candidate name.', 'error')
        return redirect(url_for('vote_cast'))

    conn = db.get_db()
    cur = conn.execute(
        'UPDATE voters SET voted = 1 WHERE nid = ? AND voted = 0', (nid,)
    )
    conn.commit()

    if cur.rowcount == 0:
        conn.close()
        return render_template('error.html',
                               message='Vote already cast or voter not found.',
                               back_url=url_for('menu'))

    block = bc.add_vote(account, candidate)
    conn.close()

    session.pop('voting_nid', None)
    session.pop('account', None)
    reset_result()

    return render_template('vote_success.html',
                           tx_hash=block['tx_hash'],
                           block_index=block['index'],
                           account=account,
                           candidate=candidate,
                           timestamp=block['timestamp'])


# ---------------------------------------------------------------------------
# Blockchain explorer
# ---------------------------------------------------------------------------
@app.route('/blockchain')
@login_required
def blockchain_explorer():
    query = request.args.get('tx', '').strip()
    block = None
    if query:
        block = bc.get_block_by_tx(query)
        if block is None:
            flash('No block found for that transaction hash.', 'error')
    all_blocks = bc.get_all_blocks()
    valid = bc.verify_chain()
    return render_template('blockchain_explorer.html',
                           blocks=all_blocks,
                           searched_block=block,
                           chain_valid=valid,
                           query=query)


# ---------------------------------------------------------------------------
# Election results
# ---------------------------------------------------------------------------
@app.route('/results')
@login_required
def election_results():
    results = bc.get_results()
    return render_template('election_results.html', results=results)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    db.init_db()
    for d in UPLOADS.values():
        os.makedirs(d, exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)
